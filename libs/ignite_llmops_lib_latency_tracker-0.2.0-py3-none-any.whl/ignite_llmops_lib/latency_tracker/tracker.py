"""LLMLatencyTracker — record and query latency measurements."""

from __future__ import annotations

import threading
from datetime import datetime, timezone

from ignite_llmops_lib.latency_tracker.histogram import LLMHistogram
from ignite_llmops_lib.latency_tracker.types import LLMLatencyRecord, LLMLatencyStats


class LLMLatencyTracker:
    """Record latency measurements and compute per-model statistics.

    Thread-safe: all public methods are protected by an internal lock.
    """

    def __init__(self) -> None:
        self._records: list[LLMLatencyRecord] = []
        self._histograms: dict[str, LLMHistogram] = {}
        self._lock = threading.Lock()

    def record(
        self,
        *,
        provider: str,
        model: str,
        ttft_ms: float = 0.0,
        ttlt_ms: float = 0.0,
        total_ms: float = 0.0,
    ) -> LLMLatencyRecord:
        """Record a single latency measurement."""
        rec = LLMLatencyRecord(
            provider=provider,
            model=model,
            ttft_ms=ttft_ms,
            ttlt_ms=ttlt_ms,
            total_ms=total_ms,
            timestamp=datetime.now(timezone.utc),
        )
        with self._lock:
            self._records.append(rec)
            key = f"{provider}/{model}"
            if key not in self._histograms:
                self._histograms[key] = LLMHistogram()
            self._histograms[key].add(total_ms)

        return rec

    def stats(self, *, provider: str | None = None, model: str | None = None) -> LLMLatencyStats:
        """Compute aggregated statistics, optionally filtered by provider/model.

        If both provider and model are given, returns stats for that specific
        provider/model pair. Otherwise aggregates across all matching records.
        """
        with self._lock:
            if provider and model:
                key = f"{provider}/{model}"
                hist = self._histograms.get(key)
                if hist is None:
                    return LLMLatencyStats()
                return hist.stats()

            # Build a temporary histogram from matching records
            hist = LLMHistogram()
            for rec in self._records:
                if provider and rec.provider != provider:
                    continue
                if model and rec.model != model:
                    continue
                hist.add(rec.total_ms)

            return hist.stats()

    @property
    def records(self) -> list[LLMLatencyRecord]:
        """Return a snapshot of all recorded latency records."""
        with self._lock:
            return list(self._records)

    def reset(self) -> None:
        """Clear all records and histograms."""
        with self._lock:
            self._records.clear()
            self._histograms.clear()
