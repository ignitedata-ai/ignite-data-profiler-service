"""ignite-llmops-lib-latency-tracker: TTFT, TTLT, P50/P95/P99 histograms for LLM calls."""

from ignite_llmops_lib.latency_tracker._version import __version__
from ignite_llmops_lib.latency_tracker.config import LLMLatencyConfig, init_llm_latency_tracker
from ignite_llmops_lib.latency_tracker.context import llm_track_latency as track_latency_ctx
from ignite_llmops_lib.latency_tracker.decorators import llm_track_latency
from ignite_llmops_lib.latency_tracker.histogram import LLMHistogram
from ignite_llmops_lib.latency_tracker.tracker import LLMLatencyTracker
from ignite_llmops_lib.latency_tracker.types import LLMLatencyRecord, LLMLatencyStats, LLMStreamTiming

__all__ = [
    "__version__",
    # Config & bootstrap
    "LLMLatencyConfig",
    "init_llm_latency_tracker",
    # Core tracker
    "LLMLatencyTracker",
    # LLMHistogram
    "LLMHistogram",
    # Convenience wrappers
    "llm_track_latency",
    "track_latency_ctx",
    # Types
    "LLMLatencyRecord",
    "LLMLatencyStats",
    "LLMStreamTiming",
]
