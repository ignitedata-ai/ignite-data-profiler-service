"""LLMHistogram — in-memory percentile storage for latency values."""

from __future__ import annotations

import bisect
import math

from ignite_llmops_lib.latency_tracker.types import LLMLatencyStats


class LLMHistogram:
    """Sorted-insert histogram supporting percentile queries.

    Stores raw values in a sorted list for exact percentile computation.
    Suitable for moderate cardinality (tens of thousands of values).
    """

    def __init__(self) -> None:
        self._values: list[float] = []

    def add(self, value: float) -> None:
        """Insert a value into the histogram, maintaining sorted order."""
        bisect.insort(self._values, value)

    @property
    def count(self) -> int:
        return len(self._values)

    def percentile(self, p: float) -> float:
        """Return the p-th percentile (0-100) using nearest-rank method.

        Raises ValueError if histogram is empty.
        """
        if not self._values:
            raise ValueError("Cannot compute percentile on empty histogram")
        if p < 0 or p > 100:
            raise ValueError(f"Percentile must be 0-100, got {p}")

        rank = (p / 100) * (len(self._values) - 1)
        lower = int(math.floor(rank))
        upper = min(lower + 1, len(self._values) - 1)
        frac = rank - lower
        return self._values[lower] + frac * (self._values[upper] - self._values[lower])

    def mean(self) -> float:
        """Return the arithmetic mean. Raises ValueError if empty."""
        if not self._values:
            raise ValueError("Cannot compute mean on empty histogram")
        return sum(self._values) / len(self._values)

    def stats(self) -> LLMLatencyStats:
        """Compute common statistics in one pass."""
        if not self._values:
            return LLMLatencyStats()
        return LLMLatencyStats(
            p50=self.percentile(50),
            p95=self.percentile(95),
            p99=self.percentile(99),
            mean=self.mean(),
            min=self._values[0],
            max=self._values[-1],
            count=len(self._values),
        )

    def reset(self) -> None:
        """Clear all values."""
        self._values.clear()
