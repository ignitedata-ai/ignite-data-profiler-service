"""@llm_track_latency decorator for wrapping async LLM call functions."""

from __future__ import annotations

import functools
import time
from collections.abc import Awaitable, Callable
from typing import Any, TypeVar

from ignite_llmops_lib.latency_tracker.tracker import LLMLatencyTracker
from ignite_llmops_lib.latency_tracker.types import LLMLatencyRecord

T = TypeVar("T")


def llm_track_latency(
    tracker: LLMLatencyTracker,
    *,
    provider: str,
    model: str,
) -> Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[tuple[T, LLMLatencyRecord]]]]:
    """Decorator that wraps an async function and records its latency.

    The decorated function returns a tuple of (original_result, LLMLatencyRecord).
    """

    def decorator(
        fn: Callable[..., Awaitable[T]],
    ) -> Callable[..., Awaitable[tuple[T, LLMLatencyRecord]]]:
        @functools.wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any) -> tuple[T, LLMLatencyRecord]:
            start = time.perf_counter()
            result = await fn(*args, **kwargs)
            total_ms = (time.perf_counter() - start) * 1000

            record = tracker.record(
                provider=provider,
                model=model,
                total_ms=total_ms,
            )
            return result, record

        return wrapper

    return decorator
