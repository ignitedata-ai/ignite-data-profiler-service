"""LLMLatencyConfig and init_llm_latency_tracker() bootstrap function."""

from __future__ import annotations

from dataclasses import dataclass

from ignite_llmops_lib.latency_tracker.tracker import LLMLatencyTracker


@dataclass(frozen=True, slots=True)
class LLMLatencyConfig:
    """Configuration for initialising a LLMLatencyTracker."""

    pass


def init_llm_latency_tracker(config: LLMLatencyConfig | None = None) -> LLMLatencyTracker:
    """Wire up all components and return a ready-to-use LLMLatencyTracker."""
    return LLMLatencyTracker()
