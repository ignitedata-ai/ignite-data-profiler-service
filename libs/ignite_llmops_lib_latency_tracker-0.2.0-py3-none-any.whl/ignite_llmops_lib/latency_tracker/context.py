"""llm_track_latency() async context manager for LLM call latency tracking."""

from __future__ import annotations

import time
from types import TracebackType

from ignite_llmops_lib.latency_tracker.tracker import LLMLatencyTracker
from ignite_llmops_lib.latency_tracker.types import LLMLatencyRecord


class LLMTrackLatencyContext:
    """Context object yielded by llm_track_latency().

    Set `ttft_ms` inside the block if you want to record time-to-first-token.
    """

    def __init__(
        self,
        tracker: LLMLatencyTracker,
        provider: str,
        model: str,
    ) -> None:
        self._tracker = tracker
        self._provider = provider
        self._model = model
        self._start: float = 0.0

        # Public: caller may set TTFT inside the block
        self.ttft_ms: float = 0.0
        self.result: LLMLatencyRecord | None = None

    async def __aenter__(self) -> LLMTrackLatencyContext:
        self._start = time.perf_counter()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        total_ms = (time.perf_counter() - self._start) * 1000
        self.result = self._tracker.record(
            provider=self._provider,
            model=self._model,
            ttft_ms=self.ttft_ms,
            ttlt_ms=total_ms,
            total_ms=total_ms,
        )


def llm_track_latency(
    tracker: LLMLatencyTracker,
    *,
    provider: str,
    model: str,
) -> LLMTrackLatencyContext:
    """Create an async context manager that tracks an LLM call's latency.

    Usage::

        async with llm_track_latency(tracker, provider="openai", model="gpt-4o") as ctx:
            response = await openai_client.chat.completions.create(...)
            ctx.ttft_ms = 42.0  # optionally set TTFT
        print(ctx.result.total_ms)
    """
    return LLMTrackLatencyContext(
        tracker=tracker,
        provider=provider,
        model=model,
    )
