"""Value objects for latency-tracker. Zero external dependencies."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


@dataclass(frozen=True, slots=True)
class LLMLatencyRecord:
    """A single latency measurement for an LLM call."""

    provider: str
    model: str
    ttft_ms: float = 0.0
    ttlt_ms: float = 0.0
    total_ms: float = 0.0
    timestamp: datetime | None = None

    def __post_init__(self) -> None:
        if not self.provider or not self.provider.strip():
            raise ValueError("provider cannot be empty")
        if not self.model or not self.model.strip():
            raise ValueError("model cannot be empty")
        for name in ("ttft_ms", "ttlt_ms", "total_ms"):
            if getattr(self, name) < 0:
                raise ValueError(f"{name} cannot be negative, got {getattr(self, name)}")


@dataclass(frozen=True, slots=True)
class LLMLatencyStats:
    """Aggregated latency statistics."""

    p50: float = 0.0
    p95: float = 0.0
    p99: float = 0.0
    mean: float = 0.0
    min: float = 0.0
    max: float = 0.0
    count: int = 0


@dataclass(frozen=True, slots=True)
class LLMStreamTiming:
    """Timing data for streaming responses."""

    first_chunk_ms: float = 0.0
    last_chunk_ms: float = 0.0
    chunk_count: int = 0
    chunk_timestamps_ms: tuple[float, ...] = field(default_factory=tuple)
