"""ignite-llmops-lib-cost-tracker: Async cost tracking for LLM API calls."""

from ignite_llmops_lib.cost_tracker._version import __version__
from ignite_llmops_lib.cost_tracker.config import LLMTrackerConfig, init_llm_tracker
from ignite_llmops_lib.cost_tracker.context import llm_track_call
from ignite_llmops_lib.cost_tracker.decorators import llm_track_cost
from ignite_llmops_lib.cost_tracker.models.tables import LLMBase, LLMCallLog, LLMPricingSnapshot
from ignite_llmops_lib.cost_tracker.pricing.calculator import calculate_llm_cost
from ignite_llmops_lib.cost_tracker.pricing.fetcher import LLMPricingFetcher
from ignite_llmops_lib.cost_tracker.pricing.registry import LLMPricingRegistry
from ignite_llmops_lib.cost_tracker.query import LLMCostQuery
from ignite_llmops_lib.cost_tracker.tracker import LLMCostTracker
from ignite_llmops_lib.cost_tracker.types import (
    LLMCallStatus,
    LLMCostBreakdown,
    LLMEnvironment,
    LLMCallInput,
    LLMCallResult,
    LLMPricingEntry,
    LLMTokenUsage,
)

__all__ = [
    "__version__",
    # Config & bootstrap
    "LLMTrackerConfig",
    "init_llm_tracker",
    # Core tracker
    "LLMCostTracker",
    # Convenience wrappers
    "llm_track_call",
    "llm_track_cost",
    # Query
    "LLMCostQuery",
    # Pricing
    "LLMPricingFetcher",
    "LLMPricingRegistry",
    "calculate_llm_cost",
    # Types
    "LLMCallStatus",
    "LLMCostBreakdown",
    "LLMEnvironment",
    "LLMCallInput",
    "LLMCallResult",
    "LLMPricingEntry",
    "LLMTokenUsage",
    # ORM
    "LLMBase",
    "LLMCallLog",
    "LLMPricingSnapshot",
]
