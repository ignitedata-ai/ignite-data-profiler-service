"""Repository classes for all ignite-llmops-lib persistence tables."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from ignite_llmops_lib.cost_tracker.models.tables import (
    LLMCircuitBreakerEventRow,
    LLMGuardrailEventRow,
    LLMGuardrailViolationRow,
    LLMLatencyLog,
    LLMLogEntryRow,
    LLMPromptRenderRow,
    LLMRateLimitSnapshotRow,
    LLMRequestContextRow,
    LLMTokenEstimateRow,
)


class LLMLatencyRepository:
    """Insert and query latency records."""

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._session_factory = session_factory

    async def insert(
        self,
        *,
        provider: str,
        model: str,
        total_ms: float,
        ttft_ms: float = 0.0,
        ttlt_ms: float = 0.0,
        chunk_count: int = 0,
        request_id: str | None = None,
        application: str = "",
        environment: str = "dev",
        tags: dict | None = None,
    ) -> str:
        row = LLMLatencyLog(
            request_id=request_id,
            provider=provider,
            model=model,
            ttft_ms=ttft_ms,
            ttlt_ms=ttlt_ms,
            total_ms=total_ms,
            chunk_count=chunk_count,
            application=application,
            environment=environment,
            tags=tags or {},
            recorded_at=datetime.now(timezone.utc),
        )
        async with self._session_factory() as session:
            session.add(row)
            await session.commit()
        return row.id


class LLMLogEntryRepository:
    """Insert and query structured call log entries."""

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._session_factory = session_factory

    async def insert(
        self,
        *,
        provider: str,
        model: str,
        prompt: str = "",
        response: str = "",
        tokens: int = 0,
        latency_ms: float = 0.0,
        status: str = "success",
        level: str = "info",
        request_id: str | None = None,
        application: str = "",
        environment: str = "dev",
        tags: dict | None = None,
        metadata: dict | None = None,
    ) -> str:
        row = LLMLogEntryRow(
            request_id=request_id,
            provider=provider,
            model=model,
            prompt=prompt,
            response=response,
            tokens=tokens,
            latency_ms=latency_ms,
            status=status,
            level=level,
            application=application,
            environment=environment,
            tags=tags or {},
            metadata_=metadata or {},
            logged_at=datetime.now(timezone.utc),
        )
        async with self._session_factory() as session:
            session.add(row)
            await session.commit()
        return row.id


class LLMGuardrailRepository:
    """Insert guardrail events and their violations."""

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._session_factory = session_factory

    async def insert(
        self,
        *,
        passed: bool,
        violation_count: int = 0,
        severities: list[str] | None = None,
        validators: list[str] | None = None,
        violations: list[dict] | None = None,
        stage: str = "input",
        request_id: str | None = None,
        application: str = "",
        environment: str = "dev",
        tags: dict | None = None,
    ) -> str:
        event = LLMGuardrailEventRow(
            request_id=request_id,
            stage=stage,
            passed=passed,
            violation_count=violation_count,
            severities=severities or [],
            validators=validators or [],
            application=application,
            environment=environment,
            tags=tags or {},
            checked_at=datetime.now(timezone.utc),
        )
        async with self._session_factory() as session:
            session.add(event)
            await session.flush()  # get event.id for FK

            for v in violations or []:
                session.add(LLMGuardrailViolationRow(
                    event_id=event.id,
                    validator=v.get("validator", ""),
                    severity=v.get("severity", "medium"),
                    message=v.get("message", ""),
                    field=v.get("field", ""),
                ))
            await session.commit()
        return event.id


class LLMRateLimitSnapshotRepository:
    """Insert rate limit capacity snapshots."""

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._session_factory = session_factory

    async def insert(
        self,
        *,
        provider: str,
        model: str,
        max_tokens_per_min: int = 0,
        max_requests_per_min: int = 0,
        remaining_tokens: int = 0,
        remaining_requests: int = 0,
        token_utilization: float = 0.0,
        request_utilization: float = 0.0,
        request_id: str | None = None,
        application: str = "",
        environment: str = "dev",
    ) -> str:
        row = LLMRateLimitSnapshotRow(
            request_id=request_id,
            provider=provider,
            model=model,
            max_tokens_per_min=max_tokens_per_min,
            max_requests_per_min=max_requests_per_min,
            remaining_tokens=remaining_tokens,
            remaining_requests=remaining_requests,
            token_utilization=token_utilization,
            request_utilization=request_utilization,
            application=application,
            environment=environment,
            snapshot_at=datetime.now(timezone.utc),
        )
        async with self._session_factory() as session:
            session.add(row)
            await session.commit()
        return row.id


class LLMCircuitBreakerRepository:
    """Insert circuit breaker state transition events."""

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._session_factory = session_factory

    async def insert(
        self,
        *,
        circuit_name: str,
        previous_state: str,
        new_state: str,
        failure_count: int = 0,
        provider: str = "",
        model: str = "",
        application: str = "",
        environment: str = "dev",
    ) -> str:
        row = LLMCircuitBreakerEventRow(
            circuit_name=circuit_name,
            provider=provider,
            model=model,
            previous_state=previous_state,
            new_state=new_state,
            failure_count=failure_count,
            application=application,
            environment=environment,
            transitioned_at=datetime.now(timezone.utc),
        )
        async with self._session_factory() as session:
            session.add(row)
            await session.commit()
        return row.id


class LLMTokenEstimateRepository:
    """Insert token estimation records."""

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._session_factory = session_factory

    async def insert(
        self,
        *,
        model: str,
        text_tokens: int = 0,
        overhead_tokens: int = 0,
        total_tokens: int = 0,
        message_count: int = 0,
        encoding: str = "",
        request_id: str | None = None,
    ) -> str:
        row = LLMTokenEstimateRow(
            request_id=request_id,
            model=model,
            text_tokens=text_tokens,
            overhead_tokens=overhead_tokens,
            total_tokens=total_tokens,
            message_count=message_count,
            encoding=encoding,
            estimated_at=datetime.now(timezone.utc),
        )
        async with self._session_factory() as session:
            session.add(row)
            await session.commit()
        return row.id


class LLMPromptRenderRepository:
    """Insert prompt template render audit records."""

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._session_factory = session_factory

    async def insert(
        self,
        *,
        template_name: str,
        template_version: int,
        variant: str = "",
        variables: dict | None = None,
        request_id: str | None = None,
        application: str = "",
        environment: str = "dev",
    ) -> str:
        row = LLMPromptRenderRow(
            request_id=request_id,
            template_name=template_name,
            template_version=template_version,
            variant=variant,
            variables=variables or {},
            application=application,
            environment=environment,
            rendered_at=datetime.now(timezone.utc),
        )
        async with self._session_factory() as session:
            session.add(row)
            await session.commit()
        return row.id


class LLMRequestContextRepository:
    """Insert application-owned request context records.

    This table is optional and fully application-owned. The library never
    reads or writes it. Applications insert one row per request_id BEFORE
    the metrics pipeline runs, making all downstream metrics queryable by
    user_id, tenant_id, session_id, app_id, or any custom attribute.
    """

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._session_factory = session_factory

    async def insert(
        self,
        *,
        request_id: str,
        user_id: str = "",
        user_name: str = "",
        user_email: str = "",
        tenant_id: str = "",
        tenant_name: str = "",
        session_id: str = "",
        app_id: str = "",
        attributes: dict | None = None,
    ) -> str:
        row = LLMRequestContextRow(
            request_id=request_id,
            user_id=user_id,
            user_name=user_name,
            user_email=user_email,
            tenant_id=tenant_id,
            tenant_name=tenant_name,
            session_id=session_id,
            app_id=app_id,
            attributes=attributes or {},
            created_at=datetime.now(timezone.utc),
        )
        async with self._session_factory() as session:
            session.add(row)
            await session.commit()
        return row.request_id
