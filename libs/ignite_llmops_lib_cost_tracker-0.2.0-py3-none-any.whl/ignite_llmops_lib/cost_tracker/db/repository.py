"""Data access layer for LLM call logs."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from ignite_llmops_lib.cost_tracker.models.tables import LLMCallLog
from ignite_llmops_lib.cost_tracker.types import LLMCostBreakdown, LLMCallInput, LLMCallResult


class LLMCallRepository:
    """Insert and query LLM call log records."""

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._session_factory = session_factory

    async def insert(
        self, call: LLMCallInput, cost: LLMCostBreakdown, pricing_version: str
    ) -> LLMCallResult:
        """Insert a single call record and return the result."""
        now = datetime.now(timezone.utc)
        row_id = str(uuid.uuid4())

        row = LLMCallLog(
            id=row_id,
            request_id=call.request_id,
            provider=call.provider,
            model=call.model,
            input_tokens=call.tokens.input_tokens,
            output_tokens=call.tokens.output_tokens,
            cache_creation_input_tokens=call.tokens.cache_creation_input_tokens,
            cache_read_input_tokens=call.tokens.cache_read_input_tokens,
            reasoning_tokens=call.tokens.reasoning_tokens,
            input_cost=cost.input_cost,
            output_cost=cost.output_cost,
            cache_creation_cost=cost.cache_creation_cost,
            cache_read_cost=cost.cache_read_cost,
            reasoning_cost=cost.reasoning_cost,
            total_cost=cost.total_cost,
            status=call.status.value,
            latency_ms=call.latency_ms,
            application=call.application,
            module=call.module,
            environment=call.environment.value,
            tags=call.tags,
            metadata_=call.metadata,
            pricing_version=pricing_version,
            called_at=call.called_at or now,
            recorded_at=now,
        )

        async with self._session_factory() as session:
            session.add(row)
            await session.commit()

        return LLMCallResult(
            id=row_id,
            cost=cost,
            pricing_version=pricing_version,
            recorded_at=now,
        )

    async def batch_insert(
        self,
        calls: list[tuple[LLMCallInput, LLMCostBreakdown, str]],
    ) -> list[LLMCallResult]:
        """Insert multiple call records in a single transaction."""
        now = datetime.now(timezone.utc)
        results: list[LLMCallResult] = []

        async with self._session_factory() as session:
            for call, cost, pricing_version in calls:
                row_id = str(uuid.uuid4())
                row = LLMCallLog(
                    id=row_id,
                    request_id=call.request_id,
                    provider=call.provider,
                    model=call.model,
                    input_tokens=call.tokens.input_tokens,
                    output_tokens=call.tokens.output_tokens,
                    cache_creation_input_tokens=call.tokens.cache_creation_input_tokens,
                    cache_read_input_tokens=call.tokens.cache_read_input_tokens,
                    reasoning_tokens=call.tokens.reasoning_tokens,
                    input_cost=cost.input_cost,
                    output_cost=cost.output_cost,
                    cache_creation_cost=cost.cache_creation_cost,
                    cache_read_cost=cost.cache_read_cost,
                    reasoning_cost=cost.reasoning_cost,
                    total_cost=cost.total_cost,
                    status=call.status.value,
                    latency_ms=call.latency_ms,
                    application=call.application,
                    module=call.module,
                    environment=call.environment.value,
                    tags=call.tags,
                    metadata_=call.metadata,
                    pricing_version=pricing_version,
                    called_at=call.called_at or now,
                    recorded_at=now,
                )
                session.add(row)
                results.append(
                    LLMCallResult(
                        id=row_id,
                        cost=cost,
                        pricing_version=pricing_version,
                        recorded_at=now,
                    )
                )
            await session.commit()

        return results

    async def get_by_id(self, record_id: str) -> LLMCallLog | None:
        """Fetch a single record by its primary key."""
        async with self._session_factory() as session:
            return await session.get(LLMCallLog, record_id)

    async def get_by_request_id(self, request_id: str) -> LLMCallLog | None:
        """Fetch a single record by request_id."""
        async with self._session_factory() as session:
            stmt = select(LLMCallLog).where(LLMCallLog.request_id == request_id)
            result = await session.execute(stmt)
            return result.scalar_one_or_none()
