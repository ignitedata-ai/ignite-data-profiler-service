"""LLMCostQuery fluent builder for querying LLM call logs."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from sqlalchemy import Select, func, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from ignite_llmops_lib.cost_tracker.models.tables import LLMCallLog


@dataclass
class LLMAggregationResult:
    """Result of an aggregation query."""

    value: float | int
    groups: dict[str, Any] = field(default_factory=dict)


class LLMCostQuery:
    """Fluent query builder for LLM call log records.

    Usage::

        query = LLMCostQuery(session_factory)
        total = await query.application("my-app").model("gpt-4o").total_cost()
    """

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self._session_factory = session_factory
        self._filters: list[Any] = []

    def _clone(self) -> LLMCostQuery:
        q = LLMCostQuery(self._session_factory)
        q._filters = list(self._filters)
        return q

    def application(self, app: str) -> LLMCostQuery:
        q = self._clone()
        q._filters.append(LLMCallLog.application == app)
        return q

    def environment(self, env: str) -> LLMCostQuery:
        q = self._clone()
        q._filters.append(LLMCallLog.environment == env)
        return q

    def model(self, model: str) -> LLMCostQuery:
        q = self._clone()
        q._filters.append(LLMCallLog.model == model)
        return q

    def provider(self, provider: str) -> LLMCostQuery:
        q = self._clone()
        q._filters.append(LLMCallLog.provider == provider)
        return q

    def status(self, status: str) -> LLMCostQuery:
        q = self._clone()
        q._filters.append(LLMCallLog.status == status)
        return q

    def since(self, dt: datetime) -> LLMCostQuery:
        q = self._clone()
        q._filters.append(LLMCallLog.called_at >= dt)
        return q

    def until(self, dt: datetime) -> LLMCostQuery:
        q = self._clone()
        q._filters.append(LLMCallLog.called_at <= dt)
        return q

    def tag(self, key: str, value: str) -> LLMCostQuery:
        """Filter by a tag key-value pair in the JSONB tags column."""
        q = self._clone()
        q._filters.append(LLMCallLog.tags[key].as_string() == value)
        return q

    def _apply_filters(self, stmt: Select[Any]) -> Select[Any]:
        for f in self._filters:
            stmt = stmt.where(f)
        return stmt

    async def total_cost(self) -> float:
        """Sum of total_cost across matched records."""
        stmt = select(func.coalesce(func.sum(LLMCallLog.total_cost), 0.0))
        stmt = self._apply_filters(stmt)
        async with self._session_factory() as session:
            result = await session.execute(stmt)
            return float(result.scalar_one())

    async def count(self) -> int:
        """Count of matched records."""
        stmt = select(func.count(LLMCallLog.id))
        stmt = self._apply_filters(stmt)
        async with self._session_factory() as session:
            result = await session.execute(stmt)
            return int(result.scalar_one())

    async def group_by_model(self) -> list[LLMAggregationResult]:
        """Total cost grouped by model."""
        stmt = select(
            LLMCallLog.model,
            func.sum(LLMCallLog.total_cost).label("total"),
            func.count(LLMCallLog.id).label("count"),
        ).group_by(LLMCallLog.model)
        stmt = self._apply_filters(stmt)
        async with self._session_factory() as session:
            result = await session.execute(stmt)
            return [
                LLMAggregationResult(
                    value=float(row.total),
                    groups={"model": row.model, "count": int(row.count)},
                )
                for row in result.all()
            ]

    async def group_by_application(self) -> list[LLMAggregationResult]:
        """Total cost grouped by application."""
        stmt = select(
            LLMCallLog.application,
            func.sum(LLMCallLog.total_cost).label("total"),
            func.count(LLMCallLog.id).label("count"),
        ).group_by(LLMCallLog.application)
        stmt = self._apply_filters(stmt)
        async with self._session_factory() as session:
            result = await session.execute(stmt)
            return [
                LLMAggregationResult(
                    value=float(row.total),
                    groups={"application": row.application, "count": int(row.count)},
                )
                for row in result.all()
            ]

    async def fetch(self, limit: int = 100, offset: int = 0) -> list[LLMCallLog]:
        """Fetch raw records with pagination."""
        stmt = (
            select(LLMCallLog)
            .order_by(LLMCallLog.called_at.desc())
            .limit(limit)
            .offset(offset)
        )
        stmt = self._apply_filters(stmt)
        async with self._session_factory() as session:
            result = await session.execute(stmt)
            return list(result.scalars().all())
