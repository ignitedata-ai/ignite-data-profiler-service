"""SQLAlchemy ORM models for all ignite-llmops-lib persistence tables."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import ARRAY, Boolean, DateTime, Float, ForeignKey, Index, Integer, String, Text
from sqlalchemy.dialects import postgresql, sqlite
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

# Use JSONB on PostgreSQL, fall back to JSON on SQLite/others
_JSONB = postgresql.JSONB().with_variant(sqlite.JSON(), "sqlite")

# Use native UUID on PostgreSQL, fall back to String(36) on SQLite/others
_UUID = postgresql.UUID(as_uuid=False).with_variant(String(36), "sqlite")

# Use TEXT[] on PostgreSQL, fall back to JSON on SQLite/others
_TEXT_ARRAY = ARRAY(Text).with_variant(sqlite.JSON(), "sqlite")


def _uuid() -> str:
    return str(uuid.uuid4())


def _now() -> datetime:
    return datetime.now(timezone.utc)


class LLMBase(DeclarativeBase):
    pass


# ── 1. Cost Tracking ─────────────────────────────────────────────────────────


class LLMCallLog(LLMBase):
    __tablename__ = "llm_call_logs"

    id: Mapped[str] = mapped_column(_UUID, primary_key=True, default=_uuid)
    request_id: Mapped[str] = mapped_column(_UUID, nullable=False)
    provider: Mapped[str] = mapped_column(String(100), nullable=False)
    model: Mapped[str] = mapped_column(String(200), nullable=False)

    # Token counts
    input_tokens: Mapped[int] = mapped_column(Integer, default=0)
    output_tokens: Mapped[int] = mapped_column(Integer, default=0)
    cache_creation_input_tokens: Mapped[int] = mapped_column(Integer, default=0)
    cache_read_input_tokens: Mapped[int] = mapped_column(Integer, default=0)
    reasoning_tokens: Mapped[int] = mapped_column(Integer, default=0)

    # Cost components
    input_cost: Mapped[float] = mapped_column(Float, default=0.0)
    output_cost: Mapped[float] = mapped_column(Float, default=0.0)
    cache_creation_cost: Mapped[float] = mapped_column(Float, default=0.0)
    cache_read_cost: Mapped[float] = mapped_column(Float, default=0.0)
    reasoning_cost: Mapped[float] = mapped_column(Float, default=0.0)
    total_cost: Mapped[float] = mapped_column(Float, default=0.0)

    # Call metadata
    status: Mapped[str] = mapped_column(String(20), default="success")
    latency_ms: Mapped[float] = mapped_column(Float, default=0.0)
    application: Mapped[str] = mapped_column(String(200), default="")
    module: Mapped[str] = mapped_column(String(200), default="")
    environment: Mapped[str] = mapped_column(String(20), default="dev")

    # Flexible dimensions
    tags: Mapped[dict] = mapped_column(_JSONB, default=dict)
    metadata_: Mapped[dict] = mapped_column("metadata", _JSONB, default=dict)

    # Pricing audit
    pricing_version: Mapped[str] = mapped_column(String(20), default="")

    # Timestamps
    called_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    __table_args__ = (
        Index("ix_llm_call_logs_request_id", "request_id"),
        Index("ix_llm_call_logs_app_env", "application", "environment"),
        Index("ix_llm_call_logs_model", "model"),
        Index("ix_llm_call_logs_called_at", "called_at"),
    )


# ── 2. Pricing Snapshots ─────────────────────────────────────────────────────


class LLMPricingSnapshot(LLMBase):
    __tablename__ = "pricing_snapshots"

    version: Mapped[str] = mapped_column(String(20), primary_key=True)
    fetched_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    source_url: Mapped[str] = mapped_column(Text, default="")
    data: Mapped[dict] = mapped_column(_JSONB, default=dict)


# ── 3. Latency Records ───────────────────────────────────────────────────────


class LLMLatencyLog(LLMBase):
    __tablename__ = "llm_latency_records"

    id: Mapped[str] = mapped_column(_UUID, primary_key=True, default=_uuid)
    request_id: Mapped[str | None] = mapped_column(_UUID, nullable=True)
    provider: Mapped[str] = mapped_column(String(100), nullable=False)
    model: Mapped[str] = mapped_column(String(200), nullable=False)

    ttft_ms: Mapped[float] = mapped_column(Float, default=0.0)
    ttlt_ms: Mapped[float] = mapped_column(Float, default=0.0)
    total_ms: Mapped[float] = mapped_column(Float, default=0.0)
    chunk_count: Mapped[int] = mapped_column(Integer, default=0)

    application: Mapped[str] = mapped_column(String(200), default="")
    environment: Mapped[str] = mapped_column(String(20), default="dev")
    tags: Mapped[dict] = mapped_column(_JSONB, default=dict)

    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    __table_args__ = (
        Index("ix_latency_provider", "provider"),
        Index("ix_latency_model", "model"),
        Index("ix_latency_recorded_at", "recorded_at"),
        Index("ix_latency_app_env", "application", "environment"),
        Index("ix_latency_request_id", "request_id"),
    )


# ── 4. Structured Call Logs ───────────────────────────────────────────────────


class LLMLogEntryRow(LLMBase):
    __tablename__ = "llm_log_entries"

    id: Mapped[str] = mapped_column(_UUID, primary_key=True, default=_uuid)
    request_id: Mapped[str | None] = mapped_column(_UUID, nullable=True)
    provider: Mapped[str] = mapped_column(String(100), nullable=False)
    model: Mapped[str] = mapped_column(String(200), nullable=False)

    prompt: Mapped[str] = mapped_column(Text, default="")
    response: Mapped[str] = mapped_column(Text, default="")
    tokens: Mapped[int] = mapped_column(Integer, default=0)
    latency_ms: Mapped[float] = mapped_column(Float, default=0.0)
    status: Mapped[str] = mapped_column(String(20), default="success")
    level: Mapped[str] = mapped_column(String(20), default="info")

    application: Mapped[str] = mapped_column(String(200), default="")
    environment: Mapped[str] = mapped_column(String(20), default="dev")
    tags: Mapped[dict] = mapped_column(_JSONB, default=dict)
    metadata_: Mapped[dict] = mapped_column("metadata", _JSONB, default=dict)

    logged_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    __table_args__ = (
        Index("ix_log_entries_provider", "provider"),
        Index("ix_log_entries_model", "model"),
        Index("ix_log_entries_status", "status"),
        Index("ix_log_entries_level", "level"),
        Index("ix_log_entries_app_env", "application", "environment"),
        Index("ix_log_entries_logged_at", "logged_at"),
    )


# ── 5. Guardrail Events ──────────────────────────────────────────────────────


class LLMGuardrailEventRow(LLMBase):
    __tablename__ = "llm_guardrail_events"

    id: Mapped[str] = mapped_column(_UUID, primary_key=True, default=_uuid)
    request_id: Mapped[str | None] = mapped_column(_UUID, nullable=True)
    stage: Mapped[str] = mapped_column(String(20), default="input")

    passed: Mapped[bool] = mapped_column(Boolean, nullable=False)
    violation_count: Mapped[int] = mapped_column(Integer, default=0)

    # Denormalized for query speed (TEXT[] on PG, JSON array on SQLite)
    severities: Mapped[list] = mapped_column(_TEXT_ARRAY, default=list)
    validators: Mapped[list] = mapped_column(_TEXT_ARRAY, default=list)

    application: Mapped[str] = mapped_column(String(200), default="")
    environment: Mapped[str] = mapped_column(String(20), default="dev")
    tags: Mapped[dict] = mapped_column(_JSONB, default=dict)

    checked_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    __table_args__ = (
        Index("ix_guardrail_passed", "passed"),
        Index("ix_guardrail_stage", "stage"),
        Index("ix_guardrail_checked_at", "checked_at"),
        Index("ix_guardrail_app_env", "application", "environment"),
    )


# ── 6. Guardrail Violations ──────────────────────────────────────────────────


class LLMGuardrailViolationRow(LLMBase):
    __tablename__ = "llm_guardrail_violations"

    id: Mapped[str] = mapped_column(_UUID, primary_key=True, default=_uuid)
    event_id: Mapped[str] = mapped_column(
        _UUID, ForeignKey("llm_guardrail_events.id", ondelete="CASCADE"), nullable=False
    )

    validator: Mapped[str] = mapped_column(String(100), nullable=False)
    severity: Mapped[str] = mapped_column(String(20), default="medium")
    message: Mapped[str] = mapped_column(Text, default="")
    field: Mapped[str] = mapped_column(String(100), default="")

    __table_args__ = (
        Index("ix_violation_event_id", "event_id"),
        Index("ix_violation_validator", "validator"),
        Index("ix_violation_severity", "severity"),
    )


# ── 7. Rate Limit Snapshots ──────────────────────────────────────────────────


class LLMRateLimitSnapshotRow(LLMBase):
    __tablename__ = "llm_rate_limit_snapshots"

    id: Mapped[str] = mapped_column(_UUID, primary_key=True, default=_uuid)
    request_id: Mapped[str | None] = mapped_column(_UUID, nullable=True)
    provider: Mapped[str] = mapped_column(String(100), nullable=False)
    model: Mapped[str] = mapped_column(String(200), nullable=False)

    max_tokens_per_min: Mapped[int] = mapped_column(Integer, default=0)
    max_requests_per_min: Mapped[int] = mapped_column(Integer, default=0)
    remaining_tokens: Mapped[int] = mapped_column(Integer, default=0)
    remaining_requests: Mapped[int] = mapped_column(Integer, default=0)

    token_utilization: Mapped[float] = mapped_column(Float, default=0.0)
    request_utilization: Mapped[float] = mapped_column(Float, default=0.0)

    application: Mapped[str] = mapped_column(String(200), default="")
    environment: Mapped[str] = mapped_column(String(20), default="dev")

    snapshot_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    __table_args__ = (
        Index("ix_rl_snapshot_provider", "provider", "model"),
        Index("ix_rl_snapshot_at", "snapshot_at"),
        Index("ix_rl_snapshot_app_env", "application", "environment"),
        Index("ix_rl_snapshot_request_id", "request_id"),
    )


# ── 8. Circuit Breaker Events ────────────────────────────────────────────────


class LLMCircuitBreakerEventRow(LLMBase):
    __tablename__ = "llm_circuit_breaker_events"

    id: Mapped[str] = mapped_column(_UUID, primary_key=True, default=_uuid)
    circuit_name: Mapped[str] = mapped_column(String(200), nullable=False)
    provider: Mapped[str] = mapped_column(String(100), default="")
    model: Mapped[str] = mapped_column(String(200), default="")

    previous_state: Mapped[str] = mapped_column(String(20), nullable=False)
    new_state: Mapped[str] = mapped_column(String(20), nullable=False)
    failure_count: Mapped[int] = mapped_column(Integer, default=0)

    application: Mapped[str] = mapped_column(String(200), default="")
    environment: Mapped[str] = mapped_column(String(20), default="dev")

    transitioned_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    __table_args__ = (
        Index("ix_cb_circuit_name", "circuit_name"),
        Index("ix_cb_new_state", "new_state"),
        Index("ix_cb_transitioned_at", "transitioned_at"),
    )


# ── 9. Token Estimates ───────────────────────────────────────────────────────


class LLMTokenEstimateRow(LLMBase):
    __tablename__ = "llm_token_estimates"

    id: Mapped[str] = mapped_column(_UUID, primary_key=True, default=_uuid)
    request_id: Mapped[str | None] = mapped_column(_UUID, nullable=True)
    model: Mapped[str] = mapped_column(String(200), nullable=False)

    text_tokens: Mapped[int] = mapped_column(Integer, default=0)
    overhead_tokens: Mapped[int] = mapped_column(Integer, default=0)
    total_tokens: Mapped[int] = mapped_column(Integer, default=0)

    message_count: Mapped[int] = mapped_column(Integer, default=0)
    encoding: Mapped[str] = mapped_column(String(100), default="")

    estimated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    __table_args__ = (
        Index("ix_token_est_model", "model"),
        Index("ix_token_est_request_id", "request_id"),
        Index("ix_token_est_at", "estimated_at"),
    )


# ── 10. Prompt Template Renders ───────────────────────────────────────────────


class LLMPromptRenderRow(LLMBase):
    __tablename__ = "llm_prompt_renders"

    id: Mapped[str] = mapped_column(_UUID, primary_key=True, default=_uuid)
    request_id: Mapped[str | None] = mapped_column(_UUID, nullable=True)
    template_name: Mapped[str] = mapped_column(String(200), nullable=False)
    template_version: Mapped[int] = mapped_column(Integer, nullable=False)

    variant: Mapped[str] = mapped_column(String(100), default="")
    variables: Mapped[dict] = mapped_column(_JSONB, default=dict)

    application: Mapped[str] = mapped_column(String(200), default="")
    environment: Mapped[str] = mapped_column(String(20), default="dev")

    rendered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


# ── 11. Request Context (optional, application-owned) ─────────────────────────


class LLMRequestContextRow(LLMBase):
    __tablename__ = "llm_request_context"

    request_id: Mapped[str] = mapped_column(_UUID, primary_key=True)
    user_id: Mapped[str] = mapped_column(String(200), default="")
    user_name: Mapped[str] = mapped_column(String(200), default="")
    user_email: Mapped[str] = mapped_column(String(200), default="")
    tenant_id: Mapped[str] = mapped_column(String(200), default="")
    tenant_name: Mapped[str] = mapped_column(String(200), default="")
    session_id: Mapped[str] = mapped_column(String(200), default="")
    app_id: Mapped[str] = mapped_column(String(200), default="")

    attributes: Mapped[dict] = mapped_column(_JSONB, default=dict)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    __table_args__ = (
        Index("ix_req_ctx_user_id", "user_id"),
        Index("ix_req_ctx_tenant_id", "tenant_id"),
        Index("ix_req_ctx_session_id", "session_id"),
        Index("ix_req_ctx_app_id", "app_id"),
        Index("ix_req_ctx_created_at", "created_at"),
    )
