"""@llm_track_cost async decorator for wrapping LLM call functions."""

from __future__ import annotations

import functools
import time
from collections.abc import Awaitable, Callable
from typing import Any, TypeVar

from ignite_llmops_lib.cost_tracker.tracker import LLMCostTracker
from ignite_llmops_lib.cost_tracker.types import LLMCallStatus, LLMCallInput, LLMCallResult, LLMTokenUsage

T = TypeVar("T")


def llm_track_cost(
    tracker: LLMCostTracker,
    *,
    provider: str,
    model: str,
    extract_tokens: Callable[[Any], LLMTokenUsage],
    application: str = "",
    module: str = "",
    tags: dict[str, str] | None = None,
) -> Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[tuple[T, LLMCallResult]]]]:
    """Decorator that wraps an async function returning an LLM response.

    The caller provides `extract_tokens` to pull LLMTokenUsage from the response.
    This keeps the library router-agnostic — no magic response parsing.

    The decorated function returns a tuple of (original_result, LLMCallResult).
    """

    def decorator(
        fn: Callable[..., Awaitable[T]],
    ) -> Callable[..., Awaitable[tuple[T, LLMCallResult]]]:
        @functools.wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any) -> tuple[T, LLMCallResult]:
            status = LLMCallStatus.SUCCESS
            tokens = LLMTokenUsage()
            result: Any = None
            start = time.perf_counter()

            try:
                result = await fn(*args, **kwargs)
                tokens = extract_tokens(result)
            except TimeoutError:
                status = LLMCallStatus.TIMEOUT
                raise
            except Exception:
                status = LLMCallStatus.ERROR
                raise
            finally:
                elapsed_ms = (time.perf_counter() - start) * 1000
                call_input = LLMCallInput(
                    provider=provider,
                    model=model,
                    tokens=tokens,
                    status=status,
                    latency_ms=elapsed_ms,
                    application=application,
                    module=module,
                    tags=dict(tags) if tags else {},
                )
                call_result = await tracker.record(call_input)

            return result, call_result

        return wrapper

    return decorator
