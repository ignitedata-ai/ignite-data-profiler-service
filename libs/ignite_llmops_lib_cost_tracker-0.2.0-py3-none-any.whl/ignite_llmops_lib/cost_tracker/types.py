"""Value objects for cost-tracker. Zero external dependencies."""

from __future__ import annotations

import enum
import uuid
from dataclasses import dataclass, field
from datetime import datetime


class LLMCallStatus(str, enum.Enum):
    SUCCESS = "success"
    ERROR = "error"
    TIMEOUT = "timeout"


class LLMEnvironment(str, enum.Enum):
    DEV = "dev"
    STAGING = "staging"
    PROD = "prod"


@dataclass(frozen=True, slots=True)
class LLMTokenUsage:
    input_tokens: int = 0
    output_tokens: int = 0
    cache_creation_input_tokens: int = 0
    cache_read_input_tokens: int = 0
    reasoning_tokens: int = 0

    def __post_init__(self) -> None:
        for name in (
            "input_tokens",
            "output_tokens",
            "cache_creation_input_tokens",
            "cache_read_input_tokens",
            "reasoning_tokens",
        ):
            if getattr(self, name) < 0:
                raise ValueError(f"{name} cannot be negative, got {getattr(self, name)}")


@dataclass(frozen=True, slots=True)
class LLMCostBreakdown:
    input_cost: float = 0.0
    output_cost: float = 0.0
    cache_creation_cost: float = 0.0
    cache_read_cost: float = 0.0
    reasoning_cost: float = 0.0

    @property
    def total_cost(self) -> float:
        return (
            self.input_cost
            + self.output_cost
            + self.cache_creation_cost
            + self.cache_read_cost
            + self.reasoning_cost
        )


@dataclass(frozen=True, slots=True)
class LLMPricingEntry:
    input_cost_per_token: float = 0.0
    output_cost_per_token: float = 0.0
    cache_creation_input_token_cost: float | None = None
    cache_read_input_token_cost: float | None = None
    reasoning_token_cost: float | None = None
    pricing_version: str = ""


@dataclass(slots=True)
class LLMCallInput:
    provider: str
    model: str
    tokens: LLMTokenUsage
    status: LLMCallStatus = LLMCallStatus.SUCCESS
    latency_ms: float = 0.0
    application: str = ""
    module: str = ""
    environment: LLMEnvironment = LLMEnvironment.DEV
    tags: dict[str, str] = field(default_factory=dict)
    metadata: dict[str, object] = field(default_factory=dict)
    request_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    called_at: datetime | None = None

    def __post_init__(self) -> None:
        if not self.provider or not self.provider.strip():
            raise ValueError("provider cannot be empty")
        if not self.model or not self.model.strip():
            raise ValueError("model cannot be empty")
        if self.latency_ms < 0:
            raise ValueError(f"latency_ms cannot be negative, got {self.latency_ms}")


@dataclass(frozen=True, slots=True)
class LLMCallResult:
    id: str
    cost: LLMCostBreakdown
    pricing_version: str
    recorded_at: datetime
