"""LLMTrackerConfig and init_llm_tracker() bootstrap function."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ignite_llmops_lib.cost_tracker.db.engine import create_engine, create_session_factory
from ignite_llmops_lib.cost_tracker.db.repository import LLMCallRepository
from ignite_llmops_lib.cost_tracker.models.tables import LLMBase
from ignite_llmops_lib.cost_tracker.pricing.fetcher import LLMPricingFetcher
from ignite_llmops_lib.cost_tracker.pricing.registry import LLMPricingRegistry
from ignite_llmops_lib.cost_tracker.tracker import LLMCostTracker
from ignite_llmops_lib.cost_tracker.types import LLMEnvironment

_DEFAULT_PRICING_URL = (
    "https://raw.githubusercontent.com/BerriAI/litellm/main/"
    "model_prices_and_context_window.json"
)


@dataclass(frozen=True, slots=True)
class LLMTrackerConfig:
    database_url: str
    pricing_json_url: str = _DEFAULT_PRICING_URL
    cache_dir: Path = Path.home() / ".cache" / "ignite_llmops_lib" / "cost_tracker"
    cache_ttl_seconds: int = 3600
    pool_size: int = 5
    max_overflow: int = 10
    echo_sql: bool = False
    default_application: str = ""
    default_environment: LLMEnvironment = LLMEnvironment.DEV
    default_tags: dict[str, str] = field(default_factory=dict)
    auto_create_tables: bool = True
    pricing_data: dict[str, Any] | None = None


async def init_llm_tracker(config: LLMTrackerConfig) -> LLMCostTracker:
    """Wire up all components and return a ready-to-use LLMCostTracker."""
    engine = create_engine(
        config.database_url,
        pool_size=config.pool_size,
        max_overflow=config.max_overflow,
        echo=config.echo_sql,
    )

    if config.auto_create_tables:
        async with engine.begin() as conn:
            await conn.run_sync(LLMBase.metadata.create_all)

    session_factory = create_session_factory(engine)
    repository = LLMCallRepository(session_factory)

    registry = LLMPricingRegistry()

    if config.pricing_data is not None:
        registry.update(config.pricing_data, "inline")
    else:
        fetcher = LLMPricingFetcher(
            url=config.pricing_json_url,
            cache_dir=config.cache_dir,
            ttl_seconds=config.cache_ttl_seconds,
        )
        pricing_data, version = await fetcher.fetch()
        registry.update(pricing_data, version)

    return LLMCostTracker(
        registry=registry,
        repository=repository,
        fetcher=LLMPricingFetcher(
            url=config.pricing_json_url,
            cache_dir=config.cache_dir,
            ttl_seconds=config.cache_ttl_seconds,
        ),
        engine=engine,
        default_application=config.default_application,
        default_environment=config.default_environment,
        default_tags=dict(config.default_tags),
    )
