"""Pure cost math — no I/O."""

from __future__ import annotations

from ignite_llmops_lib.cost_tracker.types import LLMCostBreakdown, LLMPricingEntry, LLMTokenUsage


def calculate_llm_cost(tokens: LLMTokenUsage, pricing: LLMPricingEntry) -> LLMCostBreakdown:
    """Calculate the cost breakdown for a set of token counts and pricing rates.

    Reasoning tokens fall back to the output rate if no dedicated rate exists.
    """
    input_cost = tokens.input_tokens * pricing.input_cost_per_token
    output_cost = tokens.output_tokens * pricing.output_cost_per_token

    # Cache costs: fall back to 0 if no dedicated cache rate
    cache_creation_rate = pricing.cache_creation_input_token_cost or 0.0
    cache_read_rate = pricing.cache_read_input_token_cost or 0.0
    cache_creation_cost = tokens.cache_creation_input_tokens * cache_creation_rate
    cache_read_cost = tokens.cache_read_input_tokens * cache_read_rate

    # Reasoning tokens: fall back to output rate if no dedicated rate
    reasoning_rate = (
        pricing.reasoning_token_cost
        if pricing.reasoning_token_cost is not None
        else pricing.output_cost_per_token
    )
    reasoning_cost = tokens.reasoning_tokens * reasoning_rate

    return LLMCostBreakdown(
        input_cost=input_cost,
        output_cost=output_cost,
        cache_creation_cost=cache_creation_cost,
        cache_read_cost=cache_read_cost,
        reasoning_cost=reasoning_cost,
    )
