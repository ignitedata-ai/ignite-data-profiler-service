"""LLMPricingRegistry: look up per-token pricing by model and provider."""

from __future__ import annotations

from typing import Any

from ignite_llmops_lib.cost_tracker.types import LLMPricingEntry


class LLMPricingRegistry:
    """In-memory index built from litellm pricing JSON."""

    def __init__(self) -> None:
        self._entries: dict[str, LLMPricingEntry] = {}
        self._by_provider: dict[str, dict[str, LLMPricingEntry]] = {}
        self._version: str = ""

    @property
    def version(self) -> str:
        return self._version

    def update(self, pricing_data: dict[str, Any], version: str) -> None:
        """Rebuild the index from raw litellm JSON."""
        entries: dict[str, LLMPricingEntry] = {}
        by_provider: dict[str, dict[str, LLMPricingEntry]] = {}

        for key, info in pricing_data.items():
            if not isinstance(info, dict):
                continue
            input_rate = info.get("input_cost_per_token")
            output_rate = info.get("output_cost_per_token")
            if input_rate is None and output_rate is None:
                continue

            entry = LLMPricingEntry(
                input_cost_per_token=float(input_rate or 0),
                output_cost_per_token=float(output_rate or 0),
                cache_creation_input_token_cost=(
                    float(v) if (v := info.get("cache_creation_input_token_cost")) is not None
                    else None
                ),
                cache_read_input_token_cost=(
                    float(v) if (v := info.get("cache_read_input_token_cost")) is not None
                    else None
                ),
                reasoning_token_cost=(
                    float(v) if (v := info.get("output_cost_per_reasoning_token")) is not None
                    else None
                ),
                pricing_version=version,
            )
            entries[key] = entry

            # Also index by provider
            provider = info.get("litellm_provider", "")
            if provider:
                by_provider.setdefault(provider, {})[key] = entry

        self._entries = entries
        self._by_provider = by_provider
        self._version = version

    def get_price(self, model: str, provider: str | None = None) -> LLMPricingEntry:
        """Look up pricing for a model.

        Lookup order:
        1. Exact key match (e.g. "gpt-4o" or "openai/gpt-4o")
        2. Provider-scoped search (provider/model)
        3. Fuzzy substring match across all keys
        4. Raise LookupError
        """
        # 1. Exact match
        if model in self._entries:
            return self._entries[model]

        # 2. Provider-scoped: try "provider/model"
        if provider:
            scoped_key = f"{provider}/{model}"
            if scoped_key in self._entries:
                return self._entries[scoped_key]

            # Search within provider's entries
            if provider in self._by_provider:
                provider_entries = self._by_provider[provider]
                for key, entry in provider_entries.items():
                    model_part = key.split("/", 1)[-1] if "/" in key else key
                    if model_part == model:
                        return entry

        # 3. Fuzzy substring match
        for key, entry in self._entries.items():
            if model in key or key in model:
                return entry

        raise LookupError(
            f"No pricing found for model={model!r}, provider={provider!r}. "
            f"Registry contains {len(self._entries)} entries."
        )

    def list_models(self, provider: str | None = None) -> list[str]:
        """List all known model keys, optionally filtered by provider."""
        if provider and provider in self._by_provider:
            return sorted(self._by_provider[provider].keys())
        return sorted(self._entries.keys())
