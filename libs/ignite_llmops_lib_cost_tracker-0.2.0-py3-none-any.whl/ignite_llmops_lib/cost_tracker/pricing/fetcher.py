"""Download and disk-cache litellm pricing JSON."""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any

import httpx

_DEFAULT_URL = (
    "https://raw.githubusercontent.com/BerriAI/litellm/main/"
    "model_prices_and_context_window.json"
)
_DEFAULT_CACHE_DIR = Path.home() / ".cache" / "ignite_llmops_lib" / "cost_tracker"
_DEFAULT_TTL_SECONDS = 3600  # 1 hour


class LLMPricingFetcher:
    """Fetches litellm pricing JSON via HTTP and caches to disk."""

    def __init__(
        self,
        url: str = _DEFAULT_URL,
        cache_dir: Path = _DEFAULT_CACHE_DIR,
        ttl_seconds: int = _DEFAULT_TTL_SECONDS,
    ) -> None:
        self._url = url
        self._cache_dir = cache_dir
        self._cache_file = cache_dir / "pricing.json"
        self._meta_file = cache_dir / "pricing.meta.json"
        self._ttl_seconds = ttl_seconds

    async def fetch(self, force: bool = False) -> tuple[dict[str, Any], str]:
        """Return (pricing_data, pricing_version).

        Uses disk cache if fresh enough, otherwise downloads.
        The pricing_version is the first 12 chars of the SHA-256 of the JSON.
        """
        if not force:
            cached = self._read_cache()
            if cached is not None:
                return cached

        data = await self._download()
        version = self._compute_version(data)
        self._write_cache(data, version)
        return data, version

    async def refresh(self) -> tuple[dict[str, Any], str]:
        """Force re-download, ignoring cache."""
        return await self.fetch(force=True)

    async def _download(self) -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(self._url)
            resp.raise_for_status()
            return resp.json()  # type: ignore[no-any-return]

    def _compute_version(self, data: dict[str, Any]) -> str:
        raw = json.dumps(data, sort_keys=True).encode()
        return hashlib.sha256(raw).hexdigest()[:12]

    def _read_cache(self) -> tuple[dict[str, Any], str] | None:
        if not self._cache_file.exists() or not self._meta_file.exists():
            return None

        meta = json.loads(self._meta_file.read_text())
        fetched_at = meta.get("fetched_at", 0)
        if time.time() - fetched_at > self._ttl_seconds:
            return None

        data = json.loads(self._cache_file.read_text())
        version = meta.get("version", self._compute_version(data))
        return data, version

    def _write_cache(self, data: dict[str, Any], version: str) -> None:
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._cache_file.write_text(json.dumps(data))
        self._meta_file.write_text(
            json.dumps({"version": version, "fetched_at": time.time(), "source_url": self._url})
        )
