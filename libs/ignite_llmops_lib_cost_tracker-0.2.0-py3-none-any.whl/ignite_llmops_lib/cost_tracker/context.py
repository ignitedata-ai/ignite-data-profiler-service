"""llm_track_call() async context manager for LLM call cost tracking."""

from __future__ import annotations

import time
from types import TracebackType

from ignite_llmops_lib.cost_tracker.tracker import LLMCostTracker
from ignite_llmops_lib.cost_tracker.types import (
    LLMCallStatus,
    LLMCallInput,
    LLMCallResult,
    LLMTokenUsage,
)


class LLMTrackCallContext:
    """Context object yielded by llm_track_call(). Set `tokens` inside the block."""

    def __init__(
        self,
        tracker: LLMCostTracker,
        provider: str,
        model: str,
        application: str,
        module: str,
        tags: dict[str, str],
    ) -> None:
        self._tracker = tracker
        self._provider = provider
        self._model = model
        self._application = application
        self._module = module
        self._tags = tags
        self._start: float = 0.0

        # Public attributes the caller sets/reads
        self.tokens: LLMTokenUsage = LLMTokenUsage()
        self.result: LLMCallResult | None = None

    async def __aenter__(self) -> LLMTrackCallContext:
        self._start = time.perf_counter()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        elapsed_ms = (time.perf_counter() - self._start) * 1000

        if exc_type is None:
            status = LLMCallStatus.SUCCESS
        elif issubclass(exc_type, TimeoutError):
            status = LLMCallStatus.TIMEOUT
        else:
            status = LLMCallStatus.ERROR

        call_input = LLMCallInput(
            provider=self._provider,
            model=self._model,
            tokens=self.tokens,
            status=status,
            latency_ms=elapsed_ms,
            application=self._application,
            module=self._module,
            tags=self._tags,
        )
        self.result = await self._tracker.record(call_input)


def llm_track_call(
    tracker: LLMCostTracker,
    *,
    provider: str,
    model: str,
    application: str = "",
    module: str = "",
    tags: dict[str, str] | None = None,
) -> LLMTrackCallContext:
    """Create an async context manager that tracks an LLM call's cost.

    Usage::

        async with llm_track_call(tracker, provider="openai", model="gpt-4o") as ctx:
            response = await openai_client.chat.completions.create(...)
            ctx.tokens = LLMTokenUsage(
                input_tokens=response.usage.prompt_tokens,
                output_tokens=response.usage.completion_tokens,
            )
        print(ctx.result.cost.total_cost)
    """
    return LLMTrackCallContext(
        tracker=tracker,
        provider=provider,
        model=model,
        application=application,
        module=module,
        tags=tags or {},
    )
