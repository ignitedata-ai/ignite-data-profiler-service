"""LLMCostTracker — main orchestrator that computes cost and persists records."""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncEngine

from ignite_llmops_lib.cost_tracker.db.repository import LLMCallRepository
from ignite_llmops_lib.cost_tracker.pricing.calculator import calculate_llm_cost
from ignite_llmops_lib.cost_tracker.pricing.fetcher import LLMPricingFetcher
from ignite_llmops_lib.cost_tracker.pricing.registry import LLMPricingRegistry
from ignite_llmops_lib.cost_tracker.types import (
    LLMCostBreakdown,
    LLMEnvironment,
    LLMCallInput,
    LLMCallResult,
    LLMPricingEntry,
)


class LLMCostTracker:
    """Compute cost for LLM calls and persist them to the database."""

    def __init__(
        self,
        registry: LLMPricingRegistry,
        repository: LLMCallRepository,
        fetcher: LLMPricingFetcher,
        engine: AsyncEngine,
        default_application: str = "",
        default_environment: LLMEnvironment = LLMEnvironment.DEV,
        default_tags: dict[str, str] | None = None,
    ) -> None:
        self._registry = registry
        self._repository = repository
        self._fetcher = fetcher
        self._engine = engine
        self._default_application = default_application
        self._default_environment = default_environment
        self._default_tags = default_tags or {}

    async def record(self, call: LLMCallInput) -> LLMCallResult:
        """Compute cost and persist a single call record."""
        self._apply_defaults(call)
        pricing = self._registry.get_price(call.model, call.provider)
        cost = calculate_llm_cost(call.tokens, pricing)
        return await self._repository.insert(call, cost, pricing.pricing_version)

    async def record_batch(self, calls: list[LLMCallInput]) -> list[LLMCallResult]:
        """Compute costs and persist multiple call records in one transaction."""
        batch: list[tuple[LLMCallInput, LLMCostBreakdown, str]] = []
        for call in calls:
            self._apply_defaults(call)
            pricing = self._registry.get_price(call.model, call.provider)
            cost = calculate_llm_cost(call.tokens, pricing)
            batch.append((call, cost, pricing.pricing_version))
        return await self._repository.batch_insert(batch)

    def compute_cost(self, call: LLMCallInput) -> LLMCostBreakdown:
        """Dry-run: compute cost without persisting to DB."""
        pricing = self._registry.get_price(call.model, call.provider)
        return calculate_llm_cost(call.tokens, pricing)

    def get_pricing(self, model: str, provider: str | None = None) -> LLMPricingEntry:
        """Look up the current pricing entry for a model."""
        return self._registry.get_price(model, provider)

    async def refresh_pricing(self) -> str:
        """Hot-reload pricing from upstream. Returns the new pricing version."""
        data, version = await self._fetcher.refresh()
        self._registry.update(data, version)
        return version

    async def close(self) -> None:
        """Dispose of the database engine."""
        await self._engine.dispose()

    def _apply_defaults(self, call: LLMCallInput) -> None:
        """Merge config defaults into a call input (mutates in place)."""
        if not call.application and self._default_application:
            call.application = self._default_application
        if call.environment == LLMEnvironment.DEV and self._default_environment != LLMEnvironment.DEV:
            call.environment = self._default_environment
        if self._default_tags:
            merged = dict(self._default_tags)
            merged.update(call.tags)
            call.tags = merged
