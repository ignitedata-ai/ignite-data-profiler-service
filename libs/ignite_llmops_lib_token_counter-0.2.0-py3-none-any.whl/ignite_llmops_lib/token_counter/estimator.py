"""Pure estimation functions — no state, no I/O."""

from __future__ import annotations

# Average chars per token across common encodings (empirical approximation)
_CHARS_PER_TOKEN = 4.0


def estimate_llm_tokens(text: str, *, chars_per_token: float = _CHARS_PER_TOKEN) -> int:
    """Estimate token count from text length without loading an encoding.

    This is a fast, zero-dependency fallback when tiktoken is unavailable
    or when precision is not required.
    """
    if not text:
        return 0
    return max(1, int(len(text) / chars_per_token + 0.5))
