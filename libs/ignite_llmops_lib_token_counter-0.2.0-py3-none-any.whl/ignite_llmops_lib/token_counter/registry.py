"""LLMEncodingRegistry — model-to-encoding mapping backed by tiktoken."""

from __future__ import annotations

import tiktoken

# Known model-to-encoding mappings for common providers
_MODEL_ENCODING_MAP: dict[str, str] = {
    # OpenAI GPT-4o / GPT-4 / GPT-3.5
    "gpt-4o": "o200k_base",
    "gpt-4o-mini": "o200k_base",
    "gpt-4-turbo": "cl100k_base",
    "gpt-4": "cl100k_base",
    "gpt-3.5-turbo": "cl100k_base",
    # OpenAI o-series
    "o1": "o200k_base",
    "o1-mini": "o200k_base",
    "o1-preview": "o200k_base",
    "o3-mini": "o200k_base",
    # Default fallback for Anthropic / other providers
    "claude-3-5-sonnet": "cl100k_base",
    "claude-3-opus": "cl100k_base",
    "claude-3-haiku": "cl100k_base",
}

# Per-message overhead tokens for chat models (OpenAI convention)
_MESSAGE_OVERHEAD: dict[str, int] = {
    "cl100k_base": 3,
    "o200k_base": 3,
}

_REPLY_OVERHEAD = 3  # every reply is primed with <|start|>assistant<|message|>


class LLMEncodingRegistry:
    """Maps model names to tiktoken encodings and provides token counting."""

    def __init__(self) -> None:
        self._cache: dict[str, tiktoken.Encoding] = {}

    def get_encoding(self, model: str) -> tiktoken.Encoding:
        """Return the tiktoken Encoding for a model.

        Tries tiktoken's built-in model lookup first, then falls back to
        the static mapping, then defaults to cl100k_base.
        """
        if model in self._cache:
            return self._cache[model]

        encoding = self._resolve_encoding(model)
        self._cache[model] = encoding
        return encoding

    def encoding_name_for_model(self, model: str) -> str:
        """Return the encoding name string for a model."""
        return self.get_encoding(model).name

    def message_overhead(self, model: str) -> int:
        """Return per-message overhead tokens for a model's encoding."""
        enc_name = self.encoding_name_for_model(model)
        return _MESSAGE_OVERHEAD.get(enc_name, 3)

    def reply_overhead(self) -> int:
        """Return the fixed reply-priming overhead."""
        return _REPLY_OVERHEAD

    def _resolve_encoding(self, model: str) -> tiktoken.Encoding:
        # 1. Try tiktoken's built-in model mapping
        try:
            return tiktoken.encoding_for_model(model)
        except KeyError:
            pass

        # 2. Try our static map (substring match)
        for key, enc_name in _MODEL_ENCODING_MAP.items():
            if key in model or model in key:
                return tiktoken.get_encoding(enc_name)

        # 3. Default fallback
        return tiktoken.get_encoding("cl100k_base")
