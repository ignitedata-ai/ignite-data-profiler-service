"""LLMCounterConfig and init_llm_counter() bootstrap function."""

from __future__ import annotations

from dataclasses import dataclass

from ignite_llmops_lib.token_counter.counter import LLMTokenCounter
from ignite_llmops_lib.token_counter.registry import LLMEncodingRegistry


@dataclass(frozen=True, slots=True)
class LLMCounterConfig:
    """Configuration for initialising a LLMTokenCounter."""

    default_model: str = "gpt-4o"


def init_llm_counter(config: LLMCounterConfig | None = None) -> LLMTokenCounter:
    """Wire up all components and return a ready-to-use LLMTokenCounter."""
    config = config or LLMCounterConfig()
    registry = LLMEncodingRegistry()
    return LLMTokenCounter(registry=registry, default_model=config.default_model)
