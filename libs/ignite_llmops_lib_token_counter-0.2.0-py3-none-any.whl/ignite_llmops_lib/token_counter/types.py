"""Value objects for token-counter. Zero external dependencies."""

from __future__ import annotations

import enum
from dataclasses import dataclass


class LLMMessageRole(str, enum.Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


@dataclass(frozen=True, slots=True)
class LLMTokenCount:
    """Result of a token counting operation."""

    text_tokens: int = 0
    overhead_tokens: int = 0

    @property
    def total(self) -> int:
        return self.text_tokens + self.overhead_tokens


@dataclass(frozen=True, slots=True)
class LLMMessage:
    """A chat message for token counting."""

    role: LLMMessageRole
    content: str
    name: str | None = None
