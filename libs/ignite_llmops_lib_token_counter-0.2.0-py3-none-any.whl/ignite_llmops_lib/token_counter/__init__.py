"""ignite-llmops-lib-token-counter: Pre-call token estimation across provider encodings."""

from ignite_llmops_lib.token_counter._version import __version__
from ignite_llmops_lib.token_counter.config import LLMCounterConfig, init_llm_counter
from ignite_llmops_lib.token_counter.counter import LLMTokenCounter
from ignite_llmops_lib.token_counter.estimator import estimate_llm_tokens
from ignite_llmops_lib.token_counter.registry import LLMEncodingRegistry
from ignite_llmops_lib.token_counter.types import LLMMessage, LLMMessageRole, LLMTokenCount

__all__ = [
    "__version__",
    # Config & bootstrap
    "LLMCounterConfig",
    "init_llm_counter",
    # Core counter
    "LLMTokenCounter",
    # Registry
    "LLMEncodingRegistry",
    # Pure estimation
    "estimate_llm_tokens",
    # Types
    "LLMMessage",
    "LLMMessageRole",
    "LLMTokenCount",
]
