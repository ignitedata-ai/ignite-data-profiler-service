"""LLMTokenCounter — main orchestrator for token counting."""

from __future__ import annotations

from ignite_llmops_lib.token_counter.registry import LLMEncodingRegistry
from ignite_llmops_lib.token_counter.types import LLMMessage, LLMTokenCount


class LLMTokenCounter:
    """Count tokens for text and chat messages using tiktoken encodings."""

    def __init__(
        self,
        *,
        registry: LLMEncodingRegistry | None = None,
        default_model: str = "gpt-4o",
    ) -> None:
        self._registry = registry or LLMEncodingRegistry()
        self._default_model = default_model

    def count(self, text: str, *, model: str | None = None) -> LLMTokenCount:
        """Count tokens in a plain text string.

        Returns a LLMTokenCount with text_tokens set and zero overhead.
        """
        model = model or self._default_model
        encoding = self._registry.get_encoding(model)
        tokens = len(encoding.encode(text))
        return LLMTokenCount(text_tokens=tokens, overhead_tokens=0)

    def count_messages(
        self,
        messages: list[LLMMessage],
        *,
        model: str | None = None,
    ) -> LLMTokenCount:
        """Count tokens across a list of chat messages.

        Accounts for per-message overhead and reply-priming tokens
        following the OpenAI convention.
        """
        model = model or self._default_model
        encoding = self._registry.get_encoding(model)
        per_message = self._registry.message_overhead(model)
        reply = self._registry.reply_overhead()

        text_tokens = 0
        overhead_tokens = 0

        for msg in messages:
            text_tokens += len(encoding.encode(msg.content))
            overhead_tokens += per_message  # role + separators
            if msg.name is not None:
                # name field adds one extra overhead token
                overhead_tokens += 1
                text_tokens += len(encoding.encode(msg.name))

        overhead_tokens += reply  # reply priming

        return LLMTokenCount(text_tokens=text_tokens, overhead_tokens=overhead_tokens)
