"""Shared type definitions and connector configuration models."""

from __future__ import annotations

from dataclasses import dataclass, field
import ssl
from typing import Any, Literal

from pydantic import BaseModel, Field, SecretStr, model_validator

# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------

Row = dict[str, Any]
"""A single database row, column name → value."""

Rows = list[Row]
"""A result set of rows."""


@dataclass(frozen=True, slots=True)
class QueryResult:
    """The result of a non-SELECT statement.

    Attributes:
    ----------
    rowcount:  Number of rows affected. -1 when unavailable (e.g., DDL).
    last_id:   Last inserted auto-increment ID; None for non-INSERT statements.
    """

    rowcount: int
    last_id: int | None = field(default=None)


# ---------------------------------------------------------------------------
# SSL configuration
# ---------------------------------------------------------------------------


class SSLConfig(BaseModel):
    """Optional TLS/SSL configuration for network connectors."""

    model_config = {"frozen": True}

    enabled: bool = False
    ca_cert: str | None = None
    """Path to CA certificate file for server verification."""
    client_cert: str | None = None
    """Path to client certificate file for mutual TLS."""
    client_key: str | None = None
    """Path to client private key file for mutual TLS."""
    verify: bool = True
    """Whether to verify the server's certificate. Set False only in development."""

    def to_ssl_context(self) -> ssl.SSLContext | None:
        """Build a stdlib ssl.SSLContext from this config, or return None.

        Returns:
        -------
        An ssl.SSLContext ready to pass to asyncpg/aiomysql, or None if SSL
        is disabled.
        """
        if not self.enabled:
            return None
        ctx = ssl.create_default_context(
            ssl.Purpose.SERVER_AUTH,
            cafile=self.ca_cert,
        )
        if not self.verify:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        if self.client_cert and self.client_key:
            ctx.load_cert_chain(self.client_cert, self.client_key)
        return ctx


# ---------------------------------------------------------------------------
# Base connector configuration
# ---------------------------------------------------------------------------


class BaseConnectorConfig(BaseModel):
    """Fields shared by every network-based connector."""

    model_config = {"frozen": True}

    host: str = "localhost"
    port: int
    database: str
    username: str
    password: SecretStr
    connect_timeout: float = Field(default=10.0, gt=0, le=120)
    pool_min_size: int = Field(default=1, ge=1, le=100)
    pool_max_size: int = Field(default=10, ge=1, le=100)

    @model_validator(mode="after")
    def _pool_sizes_consistent(self) -> BaseConnectorConfig:
        if self.pool_min_size > self.pool_max_size:
            raise ValueError(f"pool_min_size ({self.pool_min_size}) must be <= pool_max_size ({self.pool_max_size})")
        return self


# ---------------------------------------------------------------------------
# Connector-specific configurations
# ---------------------------------------------------------------------------


class PostgresConfig(BaseConnectorConfig):
    """Configuration for the asyncpg-based PostgreSQL connector.

    Parameter placeholders in SQL use asyncpg style: ``$1``, ``$2``, etc.

    Example:
    -------
    >>> config = PostgresConfig(
    ...     host="localhost",
    ...     database="mydb",
    ...     username="user",
    ...     password="secret",
    ... )
    """

    connector_type: Literal["postgres"] = "postgres"
    port: int = 5432
    ssl: SSLConfig = Field(default_factory=SSLConfig)
    statement_cache_size: int = Field(default=100, ge=0)
    """Number of prepared statements to cache per connection. Set 0 to disable."""
    max_inactive_connection_lifetime: float = Field(default=300.0, gt=0)
    """Close idle connections after this many seconds of inactivity."""
    command_timeout: float | None = Field(default=None, gt=0)
    """Default timeout in seconds for individual commands. None means no timeout."""


class MySQLConfig(BaseConnectorConfig):
    """Configuration for the aiomysql-based MySQL connector.

    Parameter placeholders in SQL use ``%s`` style.

    Example:
    -------
    >>> config = MySQLConfig(
    ...     host="localhost",
    ...     database="mydb",
    ...     username="user",
    ...     password="secret",
    ... )
    """

    connector_type: Literal["mysql"] = "mysql"
    port: int = 3306
    ssl: SSLConfig = Field(default_factory=SSLConfig)
    charset: str = "utf8mb4"
    autocommit: bool = True
    """Must be True for connection-pool correctness.

    With ``False``, each pooled ``execute()`` call begins an implicit MySQL
    transaction that is never committed before the connection is returned to the
    pool. aiomysql closes connections with open transactions rather than
    recycling them, so subsequent calls on other connections cannot see
    previous writes.

    Explicit transactions are managed via the ``transaction()`` context manager,
    which sends ``BEGIN`` / ``COMMIT`` / ``ROLLBACK`` regardless of this flag.
    """


class DuckDBConfig(BaseModel):
    """Configuration for the DuckDB connector.

    DuckDB operates in-process and does not use connection pooling. SSL is not
    applicable. Parameter placeholders use ``?`` style (positional list).

    Example:
    -------
    >>> config = DuckDBConfig()                          # in-memory
    >>> config = DuckDBConfig(database="/path/to/db")   # file-based
    """

    model_config = {"frozen": True}

    connector_type: Literal["duckdb"] = "duckdb"
    database: str = ":memory:"
    """Path to a DuckDB database file, or ``:memory:`` for an in-memory database."""
    read_only: bool = False
    connect_timeout: float = Field(default=10.0, gt=0, le=120)
    config: dict[str, Any] = Field(default_factory=dict)
    """DuckDB configuration options, e.g. ``{"threads": 4, "memory_limit": "2GB"}``."""


class SnowflakeConfig(BaseModel):
    """Configuration for the Snowflake connector.

    Snowflake operates via a remote cloud service and does not use host/port.
    Uses the ``snowflake-connector-python`` library (synchronous, wrapped with
    ``asyncio.to_thread``). Parameter placeholders use ``%s`` style (pyformat).

    Example:
    -------
    >>> config = SnowflakeConfig(
    ...     account="xy12345.us-east-1",
    ...     database="mydb",
    ...     username="user",
    ...     password="secret",
    ...     warehouse="COMPUTE_WH",
    ... )
    """

    model_config = {"frozen": True}

    connector_type: Literal["snowflake"] = "snowflake"
    account: str
    """Snowflake account identifier, e.g. ``"xy12345.us-east-1"``."""
    username: str
    password: SecretStr
    database: str
    schema_name: str = "PUBLIC"
    """Default schema. Named ``schema_name`` to avoid shadowing Pydantic's ``schema`` method."""
    warehouse: str | None = None
    """Warehouse to use. None means the user's default warehouse."""
    role: str | None = None
    """Role to assume. None means the user's default role."""
    connect_timeout: float = Field(default=30.0, gt=0, le=300)
    """Connection timeout in seconds. Higher default than other connectors
    because Snowflake connections involve network round-trips to a cloud service."""
    authenticator: str | None = None
    """Authentication method. None uses default (password). Other values:
    ``"externalbrowser"``, ``"snowflake_jwt"``, ``"oauth"``, etc."""
    private_key_path: str | None = None
    """Path to a PEM private key file for key-pair authentication."""


class DatabricksConfig(BaseModel):
    """Configuration for the Databricks SQL connector.

    Databricks operates via a remote cloud service using HTTP endpoints.
    Uses the ``databricks-sql-connector`` library (synchronous, wrapped with
    ``asyncio.to_thread``). Parameter placeholders use ``?`` style (positional).

    Example:
    -------
    >>> config = DatabricksConfig(
    ...     server_hostname="adb-1234567890.1.azuredatabricks.net",
    ...     http_path="/sql/1.0/warehouses/abcdef",
    ...     access_token="dapi1234567890",
    ... )
    """

    model_config = {"frozen": True}

    connector_type: Literal["databricks"] = "databricks"
    server_hostname: str
    """Databricks workspace hostname, e.g. ``"adb-1234567890.1.azuredatabricks.net"``."""
    http_path: str
    """HTTP path to SQL warehouse or cluster, e.g. ``"/sql/1.0/warehouses/abcdef"``."""
    access_token: SecretStr
    """Personal access token or service principal token."""
    catalog: str | None = None
    """Initial Unity Catalog name (requires DBR 9.0+)."""
    schema_name: str | None = None
    """Initial schema name. Named ``schema_name`` to avoid shadowing Pydantic's ``schema`` method."""
    connect_timeout: float = Field(default=30.0, gt=0, le=300)
    """Connection timeout in seconds. Higher default for cloud service."""
    session_configuration: dict[str, Any] = Field(default_factory=dict)
    """Spark session configuration parameters, e.g. ``{"spark.sql.shuffle.partitions": "10"}``."""


class RedshiftConfig(BaseModel):
    """Configuration for the AWS Redshift connector.

    Redshift uses the ``redshift_connector`` library (synchronous, wrapped with
    ``asyncio.to_thread``). Parameter placeholders use ``%s`` style (pyformat).

    Supports both password-based and IAM-based authentication. For IAM auth,
    set ``iam=True`` and provide ``cluster_identifier`` and optionally ``region``
    and ``profile``.

    Example:
    -------
    >>> config = RedshiftConfig(
    ...     host="examplecluster.abc123xyz789.us-west-1.redshift.amazonaws.com",
    ...     database="dev",
    ...     username="awsuser",
    ...     password="my_password",
    ... )
    """

    model_config = {"frozen": True}

    connector_type: Literal["redshift"] = "redshift"
    host: str
    """Redshift cluster endpoint hostname."""
    port: int = 5439
    """Redshift cluster port. Default is 5439."""
    database: str
    """Database name to connect to."""
    username: str
    """Database username."""
    password: SecretStr
    """Database password. For IAM auth this can be empty but must still be provided."""
    ssl: bool = True
    """Whether to use SSL. Redshift recommends SSL for all connections."""
    sslmode: str = "verify-ca"
    """SSL mode. Common values: ``"verify-ca"``, ``"verify-full"``, ``"prefer"``, ``"require"``."""
    connect_timeout: float = Field(default=30.0, gt=0, le=300)
    """Connection timeout in seconds. Higher default for cloud service."""
    iam: bool = False
    """Use IAM-based authentication instead of password."""
    cluster_identifier: str | None = None
    """Redshift cluster identifier. Required for IAM authentication."""
    region: str | None = None
    """AWS region for IAM authentication, e.g. ``"us-east-1"``."""
    profile: str | None = None
    """AWS profile name for IAM authentication."""
    db_user: str | None = None
    """Database user to impersonate when using IAM authentication."""


class BigQueryConfig(BaseModel):
    """Configuration for the BigQuery connector.

    BigQuery operates via a remote Google Cloud service. Uses the
    ``google-cloud-bigquery`` DB-API 2.0 module (synchronous, wrapped with
    ``asyncio.to_thread``). Parameter placeholders use ``%s`` style (pyformat).

    BigQuery auto-commits every statement. The ``transaction()`` context
    manager raises ``TransactionError`` because BigQuery does not support
    traditional transactions.

    Example:
    -------
    >>> config = BigQueryConfig(
    ...     project="my-gcp-project",
    ...     location="US",
    ...     dataset="my_dataset",
    ... )
    """

    model_config = {"frozen": True}

    connector_type: Literal["bigquery"] = "bigquery"
    project: str
    """GCP project ID."""
    credentials_path: str | None = None
    """Path to a service account JSON key file. ``None`` uses Application Default Credentials."""
    location: str | None = None
    """Default location for BigQuery jobs, e.g. ``"US"``, ``"EU"``, ``"us-central1"``."""
    dataset: str | None = None
    """Default dataset for unqualified table names."""
    connect_timeout: float = Field(default=30.0, gt=0, le=300)
    """Connection timeout in seconds. Higher default for cloud service."""


# ---------------------------------------------------------------------------
# Union type for the factory
# ---------------------------------------------------------------------------

ConnectorConfig = (
    PostgresConfig | MySQLConfig | DuckDBConfig | SnowflakeConfig | DatabricksConfig | BigQueryConfig | RedshiftConfig
)
"""Union of all supported connector configuration types."""
