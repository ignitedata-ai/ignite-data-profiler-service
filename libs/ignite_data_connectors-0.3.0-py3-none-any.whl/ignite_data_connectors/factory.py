"""Connector factory: dispatch on configuration type."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ignite_data_connectors.base import BaseConnector
from ignite_data_connectors.exceptions import ConfigurationError

if TYPE_CHECKING:
    from ignite_data_connectors.types import ConnectorConfig


def create_connector(config: ConnectorConfig) -> BaseConnector:
    """Return the correct connector instance for the given configuration.

    Imports are deferred per branch so that only the requested driver's
    package is loaded. This means you can install only the drivers you need
    (e.g. only ``duckdb``) without import errors for the others.

    Parameters
    ----------
    config:
        A validated ``PostgresConfig``, ``MySQLConfig``, or ``DuckDBConfig``
        instance.

    Returns:
    -------
    BaseConnector
        A connector instance. Call ``await connector.connect()`` before use,
        or use it as an async context manager::

            async with create_connector(config) as conn:
                rows = await conn.fetch_all("SELECT 1")

    Raises:
    ------
    ConfigurationError
        If ``config.connector_type`` is not recognised.

    Examples:
    --------
    >>> from ignite_data_connectors import create_connector, PostgresConfig
    >>> config = PostgresConfig(
    ...     host="localhost",
    ...     database="mydb",
    ...     username="user",
    ...     password="secret",
    ... )
    >>> connector = create_connector(config)
    """
    match config.connector_type:
        case "postgres":
            from ignite_data_connectors.connectors.postgres import PostgresConnector

            return PostgresConnector(config)  # type: ignore[arg-type]
        case "mysql":
            from ignite_data_connectors.connectors.mysql import MySQLConnector

            return MySQLConnector(config)  # type: ignore[arg-type]
        case "duckdb":
            from ignite_data_connectors.connectors.duckdb import DuckDBConnector

            return DuckDBConnector(config)  # type: ignore[arg-type]
        case "snowflake":
            from ignite_data_connectors.connectors.snowflake import SnowflakeConnector

            return SnowflakeConnector(config)  # type: ignore[arg-type]
        case "databricks":
            from ignite_data_connectors.connectors.databricks import DatabricksConnector

            return DatabricksConnector(config)  # type: ignore[arg-type]
        case "bigquery":
            from ignite_data_connectors.connectors.bigquery import BigQueryConnector

            return BigQueryConnector(config)  # type: ignore[arg-type]
        case "redshift":
            from ignite_data_connectors.connectors.redshift import RedshiftConnector

            return RedshiftConnector(config)  # type: ignore[arg-type]
        case _:
            raise ConfigurationError(
                f"Unknown connector type: {config.connector_type!r}. "
                "Expected one of: 'postgres', 'mysql', 'duckdb', 'snowflake', 'databricks', 'bigquery', 'redshift'."
            )
