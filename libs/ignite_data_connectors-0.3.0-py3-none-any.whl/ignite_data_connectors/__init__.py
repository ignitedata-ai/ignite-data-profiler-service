"""ignite-data-connectors — Universal async Python database connector library.

Quick start
-----------
>>> from ignite_data_connectors import create_connector, PostgresConfig
>>>
>>> config = PostgresConfig(
...     host="localhost",
...     database="mydb",
...     username="user",
...     password="secret",
... )
>>> async with create_connector(config) as conn:
...     rows = await conn.fetch_all("SELECT * FROM users WHERE active = $1", (True,))
"""

from ignite_data_connectors.base import BaseConnector
from ignite_data_connectors.exceptions import (
    ConfigurationError,
    ConnectorError,
    QueryError,
    TransactionError,
)
from ignite_data_connectors.exceptions import ConnectionError as ConnectorConnectionError
from ignite_data_connectors.factory import create_connector
from ignite_data_connectors.types import (
    BigQueryConfig,
    ConnectorConfig,
    DatabricksConfig,
    DuckDBConfig,
    MySQLConfig,
    PostgresConfig,
    QueryResult,
    RedshiftConfig,
    Row,
    Rows,
    SnowflakeConfig,
    SSLConfig,
)

__all__ = [
    "BaseConnector",
    "create_connector",
    "ConnectorConfig",
    "PostgresConfig",
    "MySQLConfig",
    "DuckDBConfig",
    "SnowflakeConfig",
    "DatabricksConfig",
    "BigQueryConfig",
    "RedshiftConfig",
    "SSLConfig",
    "QueryResult",
    "Row",
    "Rows",
    "ConfigurationError",
    "ConnectorError",
    "ConnectorConnectionError",
    "QueryError",
    "TransactionError",
]
