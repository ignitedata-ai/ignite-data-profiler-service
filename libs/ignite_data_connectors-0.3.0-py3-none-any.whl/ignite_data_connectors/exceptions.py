"""Custom exception hierarchy for ignite-data-connectors."""

from __future__ import annotations


class ConnectorError(Exception):
    """Root exception for all ignite-data-connectors errors.

    Attributes:
    ----------
    message:  Human-readable description.
    original: The underlying library exception that was wrapped, if any.
    """

    def __init__(self, message: str, original: BaseException | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.original = original

    def __str__(self) -> str:
        if self.original:
            return f"{self.message} (caused by: {type(self.original).__name__}: {self.original})"
        return self.message


class ConnectionError(ConnectorError):
    """Raised when a connection or pool cannot be established or is lost."""


class QueryError(ConnectorError):
    """Raised when SQL execution fails (syntax errors, constraint violations, etc.)."""


class TransactionError(ConnectorError):
    """Raised when a transaction cannot be started, committed, or rolled back."""


class ConfigurationError(ConnectorError):
    """Raised when connector configuration is invalid beyond Pydantic validation."""
