"""MySQL connector — async-native via aiomysql with connection pooling."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
import contextvars
import logging
from typing import TYPE_CHECKING, Any

import aiomysql

from ignite_data_connectors.base import BaseConnector
from ignite_data_connectors.exceptions import (
    ConnectionError,
    QueryError,
    TransactionError,
)
from ignite_data_connectors.types import QueryResult, Row, Rows

if TYPE_CHECKING:
    from ignite_data_connectors.types import MySQLConfig

logger = logging.getLogger(__name__)

# ContextVar holding the active transaction connection for the current async task.
# When set, execute/fetch methods use this connection instead of acquiring from pool,
# ensuring all operations within a transaction see uncommitted writes.
_active_conn: contextvars.ContextVar[aiomysql.Connection | None] = contextvars.ContextVar("_mysql_active_conn", default=None)


class MySQLConnector(BaseConnector):
    """Async MySQL connector backed by an aiomysql connection pool.

    All cursors use ``aiomysql.DictCursor`` so every row is returned as a
    ``dict[str, Any]`` without any post-processing.

    SQL parameter placeholders use ``%s`` style (standard MySQL / Python DB-API).

    Transactions are propagated transparently via a ``contextvars.ContextVar``:
    all ``execute`` / ``fetch_*`` calls within an ``async with connector.transaction()``
    block automatically use the same connection, ensuring uncommitted writes are visible.

    Parameters
    ----------
    config: MySQLConfig instance.
    """

    def __init__(self, config: MySQLConfig) -> None:  # type: ignore[override]
        super().__init__(config)
        self._config: MySQLConfig = config
        self._pool: aiomysql.Pool | None = None

    def _ensure_pool(self) -> aiomysql.Pool:
        if self._pool is None:
            raise ConnectionError("MySQL connector is not connected. Call connect() or use it as an async context manager.")
        return self._pool

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Create the aiomysql connection pool (no-op if already connected)."""
        if self._pool is not None:
            return

        cfg = self._config
        ssl_ctx = cfg.ssl.to_ssl_context()

        self._logger.info(
            "Creating MySQL pool: host=%s port=%d database=%s",
            cfg.host,
            cfg.port,
            cfg.database,
        )
        try:
            self._pool = await aiomysql.create_pool(
                host=cfg.host,
                port=cfg.port,
                db=cfg.database,
                user=cfg.username,
                password=cfg.password.get_secret_value(),
                minsize=cfg.pool_min_size,
                maxsize=cfg.pool_max_size,
                connect_timeout=cfg.connect_timeout,
                ssl=ssl_ctx,
                charset=cfg.charset,
                autocommit=cfg.autocommit,
                cursorclass=aiomysql.DictCursor,
            )
        except aiomysql.Error as exc:
            raise ConnectionError(
                f"Cannot connect to MySQL at {cfg.host}:{cfg.port}/{cfg.database}",
                original=exc,
            ) from exc
        self._logger.info("MySQL pool created (min=%d max=%d).", cfg.pool_min_size, cfg.pool_max_size)

    async def disconnect(self) -> None:
        """Close all connections in the pool."""
        if self._pool is None:
            return
        pool = self._pool
        self._pool = None
        pool.close()
        await pool.wait_closed()
        self._logger.info("MySQL pool closed.")

    async def test_connection(self) -> bool:
        """Verify connectivity by running ``SELECT 1``."""
        pool = self._ensure_pool()
        try:
            async with pool.acquire() as conn, conn.cursor() as cur:
                await cur.execute("SELECT 1")
        except aiomysql.Error as exc:
            raise ConnectionError(
                "MySQL connection test failed.",
                original=exc,
            ) from exc
        return True

    # ------------------------------------------------------------------
    # Internal: connection acquisition (respects active transaction)
    # ------------------------------------------------------------------

    @asynccontextmanager
    async def _acquire(self) -> AsyncIterator[aiomysql.Connection]:
        """Yield the active transaction connection or acquire one from the pool."""
        tx_conn = _active_conn.get()
        if tx_conn is not None:
            yield tx_conn
        else:
            pool = self._ensure_pool()
            async with pool.acquire() as conn:
                yield conn

    # ------------------------------------------------------------------
    # Query execution
    # ------------------------------------------------------------------

    async def execute(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> QueryResult:
        """Execute a non-SELECT SQL statement."""
        self._logger.debug("execute: %s | params=%s", query[:200], params)
        async with self._acquire() as conn, conn.cursor() as cur:
            try:
                await cur.execute(query, params or ())
                return QueryResult(
                    rowcount=cur.rowcount,
                    last_id=cur.lastrowid or None,
                )
            except aiomysql.Error as exc:
                raise QueryError(
                    f"MySQL query failed: {query[:80]}",
                    original=exc,
                ) from exc

    async def fetch_one(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Row | None:
        """Execute a SELECT and return the first row as a dict, or None."""
        self._logger.debug("fetch_one: %s | params=%s", query[:200], params)
        async with self._acquire() as conn, conn.cursor() as cur:
            try:
                await cur.execute(query, params or ())
                return await cur.fetchone()  # DictCursor returns dict or None
            except aiomysql.Error as exc:
                raise QueryError(
                    f"MySQL query failed: {query[:80]}",
                    original=exc,
                ) from exc

    async def fetch_all(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Rows:
        """Execute a SELECT and return all rows as a list of dicts."""
        self._logger.debug("fetch_all: %s | params=%s", query[:200], params)
        async with self._acquire() as conn, conn.cursor() as cur:
            try:
                await cur.execute(query, params or ())
                # aiomysql DictCursor.fetchall() returns () for empty results;
                # always normalise to list so callers get a consistent type.
                return list(await cur.fetchall())
            except aiomysql.Error as exc:
                raise QueryError(
                    f"MySQL query failed: {query[:80]}",
                    original=exc,
                ) from exc

    async def execute_many(
        self,
        query: str,
        params_seq: list[tuple[Any, ...]] | list[list[Any]],
    ) -> QueryResult:
        """Execute a parameterised statement in bulk using aiomysql executemany."""
        self._logger.debug("execute_many: %s | %d param sets", query[:200], len(params_seq))
        async with self._acquire() as conn, conn.cursor() as cur:
            try:
                await cur.executemany(query, params_seq)
                return QueryResult(
                    rowcount=cur.rowcount,
                    last_id=cur.lastrowid or None,
                )
            except aiomysql.Error as exc:
                raise QueryError(
                    f"MySQL execute_many failed: {query[:80]}",
                    original=exc,
                ) from exc

    # ------------------------------------------------------------------
    # Transactions
    # ------------------------------------------------------------------

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[None]:
        """Async context manager wrapping work in a MySQL transaction.

        Acquires a dedicated connection from the pool, begins a transaction,
        and sets the connection as active for the current async task via
        ``_active_conn``. All ``execute`` / ``fetch_*`` calls within the block
        automatically use this connection.

        Commits on success, rolls back and raises ``TransactionError`` on failure.
        """
        pool = self._ensure_pool()
        conn: aiomysql.Connection = await pool.acquire()
        try:
            await conn.begin()
            token = _active_conn.set(conn)
            self._logger.debug("MySQL transaction begun.")
            try:
                yield
                await conn.commit()
                self._logger.debug("MySQL transaction committed.")
            except Exception as exc:
                try:
                    await conn.rollback()
                    self._logger.debug("MySQL transaction rolled back.")
                except aiomysql.Error:
                    pass  # Best-effort rollback
                raise TransactionError(
                    "MySQL transaction rolled back due to an error.",
                    original=exc,
                ) from exc
            finally:
                _active_conn.reset(token)
        finally:
            pool.release(conn)
