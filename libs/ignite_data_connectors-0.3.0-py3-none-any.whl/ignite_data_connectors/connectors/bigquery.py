"""BigQuery connector — synchronous google-cloud-bigquery DB-API wrapped with asyncio.to_thread."""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
import logging
from typing import TYPE_CHECKING, Any

from google.cloud import bigquery
from google.cloud.bigquery import dbapi
from google.cloud.bigquery.dbapi.exceptions import DatabaseError

from ignite_data_connectors.base import BaseConnector
from ignite_data_connectors.exceptions import (
    ConnectionError,
    QueryError,
    TransactionError,
)
from ignite_data_connectors.types import QueryResult, Row, Rows

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from google.cloud.bigquery.dbapi.connection import Connection as DBAPIConnection

    from ignite_data_connectors.types import BigQueryConfig

logger = logging.getLogger(__name__)


class BigQueryConnector(BaseConnector):
    """Async-compatible BigQuery connector.

    Google Cloud BigQuery's Python driver is synchronous. All blocking calls
    are dispatched to a thread pool via ``asyncio.to_thread``.

    BigQuery auto-commits every statement. The ``transaction()`` context
    manager raises ``TransactionError`` because BigQuery does not support
    traditional transactions.

    Parameters
    ----------
    config: BigQueryConfig instance with project, credentials, and optional settings.
    """

    def __init__(self, config: BigQueryConfig) -> None:  # type: ignore[override]
        super().__init__(config)
        self._config: BigQueryConfig = config
        self._client: bigquery.Client | None = None
        self._conn: DBAPIConnection | None = None

    def _ensure_connected(self) -> DBAPIConnection:
        if self._conn is None:
            raise ConnectionError("BigQuery connector is not connected. Call connect() or use as an async context manager.")
        return self._conn

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Open the BigQuery connection (no-op if already connected)."""
        if self._conn is not None:
            return

        cfg = self._config

        def _open() -> tuple[bigquery.Client, DBAPIConnection]:
            client_kwargs: dict[str, Any] = {"project": cfg.project}
            if cfg.location is not None:
                client_kwargs["location"] = cfg.location
            if cfg.credentials_path is not None:
                from google.oauth2 import service_account

                credentials = service_account.Credentials.from_service_account_file(cfg.credentials_path)
                client_kwargs["credentials"] = credentials

            client = bigquery.Client(**client_kwargs)

            if cfg.dataset is not None:
                client.default_query_job_config = bigquery.QueryJobConfig(default_dataset=f"{cfg.project}.{cfg.dataset}")

            conn = dbapi.connect(client=client)
            return client, conn

        self._logger.info(
            "Connecting to BigQuery: project=%s location=%s",
            cfg.project,
            cfg.location,
        )
        try:
            self._client, self._conn = await asyncio.wait_for(
                asyncio.to_thread(_open),
                timeout=cfg.connect_timeout,
            )
        except Exception as exc:
            raise ConnectionError(
                f"Cannot connect to BigQuery project: {cfg.project}",
                original=exc,
            ) from exc
        self._logger.info("BigQuery connection established.")

    async def disconnect(self) -> None:
        """Close the BigQuery connection and client."""
        if self._conn is None:
            return
        conn = self._conn
        client = self._client
        self._conn = None
        self._client = None

        def _close() -> None:
            conn.close()
            if client is not None:
                client.close()

        await asyncio.to_thread(_close)
        self._logger.info("BigQuery connection closed.")

    async def test_connection(self) -> bool:
        """Verify the connection by executing ``SELECT 1``."""
        conn = self._ensure_connected()

        def _ping() -> None:
            cur = conn.cursor()
            try:
                cur.execute("SELECT 1")
            finally:
                cur.close()

        try:
            await asyncio.to_thread(_ping)
        except DatabaseError as exc:
            raise ConnectionError(
                "BigQuery connection test failed.",
                original=exc,
            ) from exc
        return True

    # ------------------------------------------------------------------
    # Query execution
    # ------------------------------------------------------------------

    async def execute(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> QueryResult:
        """Execute a non-SELECT SQL statement."""
        conn = self._ensure_connected()
        p = tuple(params) if params else None
        self._logger.debug("execute: %s | params=%s", query[:200], p)

        def _run() -> QueryResult:
            cur = conn.cursor()
            try:
                cur.execute(query, p)
                rowcount = cur.rowcount if cur.rowcount is not None else -1
                return QueryResult(rowcount=rowcount)
            finally:
                cur.close()

        try:
            return await asyncio.to_thread(_run)
        except DatabaseError as exc:
            raise QueryError(
                f"BigQuery query failed: {query[:80]}",
                original=exc,
            ) from exc

    async def fetch_one(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Row | None:
        """Execute a SELECT and return the first row as a dict, or None."""
        conn = self._ensure_connected()
        p = tuple(params) if params else None
        self._logger.debug("fetch_one: %s | params=%s", query[:200], p)

        def _run() -> Row | None:
            cur = conn.cursor()
            try:
                cur.execute(query, p)
                row = cur.fetchone()
                if row is None:
                    return None
                cols = [desc[0] for desc in cur.description]
                return dict(zip(cols, row, strict=True))
            finally:
                cur.close()

        try:
            return await asyncio.to_thread(_run)
        except DatabaseError as exc:
            raise QueryError(
                f"BigQuery query failed: {query[:80]}",
                original=exc,
            ) from exc

    async def fetch_all(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Rows:
        """Execute a SELECT and return all rows as a list of dicts."""
        conn = self._ensure_connected()
        p = tuple(params) if params else None
        self._logger.debug("fetch_all: %s | params=%s", query[:200], p)

        def _run() -> Rows:
            cur = conn.cursor()
            try:
                cur.execute(query, p)
                rows = cur.fetchall()
                if not rows:
                    return []
                cols = [desc[0] for desc in cur.description]
                return [dict(zip(cols, row, strict=True)) for row in rows]
            finally:
                cur.close()

        try:
            return await asyncio.to_thread(_run)
        except DatabaseError as exc:
            raise QueryError(
                f"BigQuery query failed: {query[:80]}",
                original=exc,
            ) from exc

    async def execute_many(
        self,
        query: str,
        params_seq: list[tuple[Any, ...]] | list[list[Any]],
    ) -> QueryResult:
        """Execute a parameterised statement repeatedly in bulk.

        Returns immediately with ``rowcount=-1`` when ``params_seq`` is empty.
        """
        conn = self._ensure_connected()
        if not params_seq:
            return QueryResult(rowcount=-1)
        self._logger.debug("execute_many: %s | %d param sets", query[:200], len(params_seq))

        def _run() -> QueryResult:
            cur = conn.cursor()
            try:
                cur.executemany(query, params_seq)
                rowcount = cur.rowcount if cur.rowcount is not None else -1
                return QueryResult(rowcount=rowcount)
            finally:
                cur.close()

        try:
            return await asyncio.to_thread(_run)
        except DatabaseError as exc:
            raise QueryError(
                f"BigQuery execute_many failed: {query[:80]}",
                original=exc,
            ) from exc

    # ------------------------------------------------------------------
    # Transactions
    # ------------------------------------------------------------------

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[None]:
        """BigQuery does not support transactions.

        Every statement is auto-committed immediately. This method always
        raises ``TransactionError``.
        """
        raise TransactionError("BigQuery does not support transactions. Each statement is auto-committed.")
        yield  # pragma: no cover — unreachable, required by generator protocol
