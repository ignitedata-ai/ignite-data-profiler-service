"""Concrete connector implementations.

The recommended entry point is the ``create_connector`` factory in
``ignite_data_connectors.factory``. Import concrete classes directly only
when subclassing or for advanced use cases.
"""
