"""Databricks SQL connector — synchronous databricks-sql-connector wrapped with asyncio.to_thread."""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
import contextvars
import logging
from typing import TYPE_CHECKING, Any

import databricks.sql
from databricks.sql.exc import Error as DatabricksError

from ignite_data_connectors.base import BaseConnector
from ignite_data_connectors.exceptions import (
    ConnectionError,
    QueryError,
    TransactionError,
)
from ignite_data_connectors.types import QueryResult, Row, Rows

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from databricks.sql.client import Connection as DatabricksConnection

    from ignite_data_connectors.types import DatabricksConfig

logger = logging.getLogger(__name__)

# ContextVar to track whether the current async task is inside a Databricks transaction.
# Used by transaction() to manage BEGIN/COMMIT/ROLLBACK flow.
_in_transaction: contextvars.ContextVar[bool] = contextvars.ContextVar("_databricks_in_transaction", default=False)


class DatabricksConnector(BaseConnector):
    """Async-compatible Databricks SQL connector.

    The Databricks SQL Python driver is synchronous. All blocking calls are
    dispatched to a thread pool via ``asyncio.to_thread``. A lock serialises
    write operations to prevent concurrent transaction interleaving.

    Parameters
    ----------
    config: DatabricksConfig instance with server hostname, HTTP path, and credentials.
    """

    def __init__(self, config: DatabricksConfig) -> None:  # type: ignore[override]
        super().__init__(config)
        self._config: DatabricksConfig = config
        self._conn: DatabricksConnection | None = None
        self._write_lock = asyncio.Lock()

    def _ensure_connected(self) -> DatabricksConnection:
        if self._conn is None:
            raise ConnectionError("Databricks connector is not connected. Call connect() or use as an async context manager.")
        return self._conn

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Open the Databricks connection (no-op if already connected)."""
        if self._conn is not None:
            return

        cfg = self._config

        def _open() -> DatabricksConnection:
            connect_kwargs: dict[str, Any] = {
                "server_hostname": cfg.server_hostname,
                "http_path": cfg.http_path,
                "access_token": cfg.access_token.get_secret_value(),
                "ignore_transactions": False,
            }
            if cfg.catalog is not None:
                connect_kwargs["catalog"] = cfg.catalog
            if cfg.schema_name is not None:
                connect_kwargs["schema"] = cfg.schema_name
            if cfg.session_configuration:
                connect_kwargs["session_configuration"] = cfg.session_configuration
            return databricks.sql.connect(**connect_kwargs)

        self._logger.info(
            "Connecting to Databricks: server_hostname=%s http_path=%s",
            cfg.server_hostname,
            cfg.http_path,
        )
        try:
            self._conn = await asyncio.wait_for(
                asyncio.to_thread(_open),
                timeout=cfg.connect_timeout,
            )
        except DatabricksError as exc:
            raise ConnectionError(
                f"Cannot connect to Databricks: {cfg.server_hostname}",
                original=exc,
            ) from exc
        self._logger.info("Databricks connection established.")

    async def disconnect(self) -> None:
        """Close the Databricks connection."""
        if self._conn is None:
            return
        conn = self._conn
        self._conn = None

        def _close() -> None:
            conn.close()

        await asyncio.to_thread(_close)
        self._logger.info("Databricks connection closed.")

    async def test_connection(self) -> bool:
        """Verify the connection by executing ``SELECT 1``."""
        conn = self._ensure_connected()

        def _ping() -> None:
            cur = conn.cursor()
            try:
                cur.execute("SELECT 1")
            finally:
                cur.close()

        try:
            await asyncio.to_thread(_ping)
        except DatabricksError as exc:
            raise ConnectionError(
                "Databricks connection test failed.",
                original=exc,
            ) from exc
        return True

    # ------------------------------------------------------------------
    # Query execution
    # ------------------------------------------------------------------

    async def execute(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> QueryResult:
        """Execute a non-SELECT SQL statement."""
        conn = self._ensure_connected()
        p = list(params) if params else None
        self._logger.debug("execute: %s | params=%s", query[:200], p)

        def _run() -> QueryResult:
            cur = conn.cursor()
            try:
                cur.execute(query, p)
                rowcount = cur.rowcount if cur.rowcount is not None else -1
                return QueryResult(rowcount=rowcount)
            finally:
                cur.close()

        try:
            return await asyncio.to_thread(_run)
        except DatabricksError as exc:
            raise QueryError(
                f"Databricks query failed: {query[:80]}",
                original=exc,
            ) from exc

    async def fetch_one(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Row | None:
        """Execute a SELECT and return the first row as a dict, or None."""
        conn = self._ensure_connected()
        p = list(params) if params else None
        self._logger.debug("fetch_one: %s | params=%s", query[:200], p)

        def _run() -> Row | None:
            cur = conn.cursor()
            try:
                cur.execute(query, p)
                row = cur.fetchone()
                if row is None:
                    return None
                return row.asDict()
            finally:
                cur.close()

        try:
            return await asyncio.to_thread(_run)
        except DatabricksError as exc:
            raise QueryError(
                f"Databricks query failed: {query[:80]}",
                original=exc,
            ) from exc

    async def fetch_all(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Rows:
        """Execute a SELECT and return all rows as a list of dicts."""
        conn = self._ensure_connected()
        p = list(params) if params else None
        self._logger.debug("fetch_all: %s | params=%s", query[:200], p)

        def _run() -> Rows:
            cur = conn.cursor()
            try:
                cur.execute(query, p)
                rows = cur.fetchall()
                if not rows:
                    return []
                return [row.asDict() for row in rows]
            finally:
                cur.close()

        try:
            return await asyncio.to_thread(_run)
        except DatabricksError as exc:
            raise QueryError(
                f"Databricks query failed: {query[:80]}",
                original=exc,
            ) from exc

    async def execute_many(
        self,
        query: str,
        params_seq: list[tuple[Any, ...]] | list[list[Any]],
    ) -> QueryResult:
        """Execute a parameterised statement repeatedly in bulk.

        Returns immediately with ``rowcount=-1`` when ``params_seq`` is empty.
        """
        conn = self._ensure_connected()
        if not params_seq:
            return QueryResult(rowcount=-1)
        self._logger.debug("execute_many: %s | %d param sets", query[:200], len(params_seq))

        def _run() -> QueryResult:
            cur = conn.cursor()
            try:
                cur.executemany(query, params_seq)
                rowcount = cur.rowcount if cur.rowcount is not None else -1
                return QueryResult(rowcount=rowcount)
            finally:
                cur.close()

        try:
            return await asyncio.to_thread(_run)
        except DatabricksError as exc:
            raise QueryError(
                f"Databricks execute_many failed: {query[:80]}",
                original=exc,
            ) from exc

    # ------------------------------------------------------------------
    # Transactions
    # ------------------------------------------------------------------

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[None]:
        """Async context manager wrapping work in a Databricks transaction.

        Acquires the write lock for the duration to prevent interleaving.
        Commits on success, rolls back and raises ``TransactionError`` on failure.
        """
        conn = self._ensure_connected()

        async with self._write_lock:

            def _begin() -> None:
                cur = conn.cursor()
                try:
                    cur.execute("BEGIN")
                finally:
                    cur.close()

            await asyncio.to_thread(_begin)
            self._logger.debug("Databricks transaction begun.")
            token = _in_transaction.set(True)
            try:
                yield
                await asyncio.to_thread(conn.commit)
                self._logger.debug("Databricks transaction committed.")
            except Exception as exc:
                try:
                    await asyncio.to_thread(conn.rollback)
                    self._logger.debug("Databricks transaction rolled back.")
                except DatabricksError:
                    pass  # Best-effort rollback; original exception takes priority
                raise TransactionError(
                    "Databricks transaction rolled back due to an error.",
                    original=exc,
                ) from exc
            finally:
                _in_transaction.reset(token)
