"""AWS Redshift connector — synchronous redshift_connector wrapped with asyncio.to_thread."""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
import contextvars
from typing import TYPE_CHECKING, Any

import redshift_connector
from redshift_connector import Error as RedshiftError

from ignite_data_connectors.base import BaseConnector
from ignite_data_connectors.exceptions import (
    ConnectionError,
    QueryError,
    TransactionError,
)
from ignite_data_connectors.types import QueryResult, Row, Rows

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from ignite_data_connectors.types import RedshiftConfig

# ContextVar to track whether the current async task is inside a Redshift transaction.
_in_transaction: contextvars.ContextVar[bool] = contextvars.ContextVar("_redshift_in_transaction", default=False)


class RedshiftConnector(BaseConnector):
    """Async-compatible AWS Redshift connector.

    Redshift's Python driver is synchronous. All blocking calls are dispatched
    to a thread pool via ``asyncio.to_thread``. A lock serialises write
    operations to prevent concurrent transaction interleaving.

    SQL parameter placeholders use ``%s`` style (DB-API 2.0 paramstyle).

    Parameters
    ----------
    config: RedshiftConfig instance with host, credentials, and optional settings.
    """

    def __init__(self, config: RedshiftConfig) -> None:  # type: ignore[override]
        super().__init__(config)
        self._config: RedshiftConfig = config
        self._conn: redshift_connector.Connection | None = None
        self._write_lock = asyncio.Lock()

    def _ensure_connected(self) -> redshift_connector.Connection:
        if self._conn is None:
            raise ConnectionError("Redshift connector is not connected. Call connect() or use as an async context manager.")
        return self._conn

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Open the Redshift connection (no-op if already connected)."""
        if self._conn is not None:
            return

        cfg = self._config

        def _open() -> redshift_connector.Connection:
            connect_kwargs: dict[str, Any] = {
                "host": cfg.host,
                "port": cfg.port,
                "database": cfg.database,
                "user": cfg.username,
                "password": cfg.password.get_secret_value(),
                "ssl": cfg.ssl,
                "sslmode": cfg.sslmode,
                "timeout": int(cfg.connect_timeout),
            }
            if cfg.iam:
                connect_kwargs["iam"] = True
            if cfg.cluster_identifier is not None:
                connect_kwargs["cluster_identifier"] = cfg.cluster_identifier
            if cfg.region is not None:
                connect_kwargs["region"] = cfg.region
            if cfg.profile is not None:
                connect_kwargs["profile"] = cfg.profile
            if cfg.db_user is not None:
                connect_kwargs["db_user"] = cfg.db_user
            conn = redshift_connector.connect(**connect_kwargs)
            conn.autocommit = True
            return conn

        self._logger.info(
            "Connecting to Redshift: host=%s port=%d database=%s",
            cfg.host,
            cfg.port,
            cfg.database,
        )
        try:
            self._conn = await asyncio.wait_for(
                asyncio.to_thread(_open),
                timeout=cfg.connect_timeout,
            )
        except RedshiftError as exc:
            raise ConnectionError(
                f"Cannot connect to Redshift at {cfg.host}:{cfg.port}/{cfg.database}",
                original=exc,
            ) from exc
        self._logger.info("Redshift connection established.")

    async def disconnect(self) -> None:
        """Close the Redshift connection."""
        if self._conn is None:
            return
        conn = self._conn
        self._conn = None

        def _close() -> None:
            conn.close()

        await asyncio.to_thread(_close)
        self._logger.info("Redshift connection closed.")

    async def test_connection(self) -> bool:
        """Verify the connection by executing ``SELECT 1``."""
        conn = self._ensure_connected()

        def _ping() -> None:
            cur = conn.cursor()
            try:
                cur.execute("SELECT 1")
            finally:
                cur.close()

        try:
            await asyncio.to_thread(_ping)
        except RedshiftError as exc:
            raise ConnectionError(
                "Redshift connection test failed.",
                original=exc,
            ) from exc
        return True

    # ------------------------------------------------------------------
    # Query execution
    # ------------------------------------------------------------------

    async def execute(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> QueryResult:
        """Execute a non-SELECT SQL statement."""
        conn = self._ensure_connected()
        p = tuple(params) if params else None
        self._logger.debug("execute: %s | params=%s", query[:200], p)

        def _run() -> QueryResult:
            cur = conn.cursor()
            try:
                cur.execute(query, p)
                rowcount = cur.rowcount if cur.rowcount is not None else -1
                return QueryResult(rowcount=rowcount)
            finally:
                cur.close()

        try:
            return await asyncio.to_thread(_run)
        except RedshiftError as exc:
            raise QueryError(
                f"Redshift query failed: {query[:80]}",
                original=exc,
            ) from exc

    async def fetch_one(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Row | None:
        """Execute a SELECT and return the first row as a dict, or None."""
        conn = self._ensure_connected()
        p = tuple(params) if params else None
        self._logger.debug("fetch_one: %s | params=%s", query[:200], p)

        def _run() -> Row | None:
            cur = conn.cursor()
            try:
                cur.execute(query, p)
                row = cur.fetchone()
                if row is None:
                    return None
                cols = [desc[0] for desc in cur.description]
                return dict(zip(cols, row, strict=True))
            finally:
                cur.close()

        try:
            return await asyncio.to_thread(_run)
        except RedshiftError as exc:
            raise QueryError(
                f"Redshift query failed: {query[:80]}",
                original=exc,
            ) from exc

    async def fetch_all(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Rows:
        """Execute a SELECT and return all rows as a list of dicts."""
        conn = self._ensure_connected()
        p = tuple(params) if params else None
        self._logger.debug("fetch_all: %s | params=%s", query[:200], p)

        def _run() -> Rows:
            cur = conn.cursor()
            try:
                cur.execute(query, p)
                rows = cur.fetchall()
                if not rows:
                    return []
                cols = [desc[0] for desc in cur.description]
                return [dict(zip(cols, row, strict=True)) for row in rows]
            finally:
                cur.close()

        try:
            return await asyncio.to_thread(_run)
        except RedshiftError as exc:
            raise QueryError(
                f"Redshift query failed: {query[:80]}",
                original=exc,
            ) from exc

    async def execute_many(
        self,
        query: str,
        params_seq: list[tuple[Any, ...]] | list[list[Any]],
    ) -> QueryResult:
        """Execute a parameterised statement repeatedly in bulk.

        Returns immediately with ``rowcount=-1`` when ``params_seq`` is empty.
        """
        conn = self._ensure_connected()
        if not params_seq:
            return QueryResult(rowcount=-1)
        self._logger.debug("execute_many: %s | %d param sets", query[:200], len(params_seq))

        def _run() -> QueryResult:
            cur = conn.cursor()
            try:
                cur.executemany(query, params_seq)
                rowcount = cur.rowcount if cur.rowcount is not None else -1
                return QueryResult(rowcount=rowcount)
            finally:
                cur.close()

        try:
            return await asyncio.to_thread(_run)
        except RedshiftError as exc:
            raise QueryError(
                f"Redshift execute_many failed: {query[:80]}",
                original=exc,
            ) from exc

    # ------------------------------------------------------------------
    # Transactions
    # ------------------------------------------------------------------

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[None]:
        """Async context manager wrapping work in a Redshift transaction.

        Acquires the write lock for the duration to prevent interleaving.
        Commits on success, rolls back and raises ``TransactionError`` on failure.
        """
        conn = self._ensure_connected()

        async with self._write_lock:

            def _begin() -> None:
                cur = conn.cursor()
                try:
                    cur.execute("BEGIN")
                finally:
                    cur.close()

            await asyncio.to_thread(_begin)
            self._logger.debug("Redshift transaction begun.")
            token = _in_transaction.set(True)
            try:
                yield
                await asyncio.to_thread(conn.commit)
                self._logger.debug("Redshift transaction committed.")
            except Exception as exc:
                try:
                    await asyncio.to_thread(conn.rollback)
                    self._logger.debug("Redshift transaction rolled back.")
                except RedshiftError:
                    pass  # Best-effort rollback; original exception takes priority
                raise TransactionError(
                    "Redshift transaction rolled back due to an error.",
                    original=exc,
                ) from exc
            finally:
                _in_transaction.reset(token)
