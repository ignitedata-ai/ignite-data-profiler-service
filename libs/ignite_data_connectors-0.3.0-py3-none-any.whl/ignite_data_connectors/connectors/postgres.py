"""PostgreSQL connector — async-native via asyncpg with connection pooling."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
import contextvars
import io
import logging
import re
import select
import socketserver
import threading
from typing import TYPE_CHECKING, Any

import asyncpg
import paramiko

from ignite_data_connectors.base import BaseConnector
from ignite_data_connectors.exceptions import (
    ConnectionError,
    QueryError,
    TransactionError,
)
from ignite_data_connectors.types import QueryResult, Row, Rows

if TYPE_CHECKING:
    from asyncpg.pool import PoolConnectionProxy

    from ignite_data_connectors.types import PostgresConfig, SSHTunnelConfig

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Paramiko-based SSH tunnel (replaces unmaintained sshtunnel which broke on
# paramiko >= 4.0 when DSSKey was removed).
# ---------------------------------------------------------------------------


def _load_ssh_private_key(pkey_str: str, passphrase: str | None) -> paramiko.PKey:
    """Try loading a private key as RSA, ECDSA, or Ed25519."""
    pkey_file = io.StringIO(pkey_str)
    errors: list[Exception] = []
    for key_cls in (paramiko.RSAKey, paramiko.ECDSAKey, paramiko.Ed25519Key):
        try:
            pkey_file.seek(0)
            return key_cls.from_private_key(pkey_file, password=passphrase)
        except paramiko.SSHException as exc:
            errors.append(exc)
    raise paramiko.SSHException(f"Could not load private key (tried RSA, ECDSA, Ed25519): {errors[-1]}")


class _TunnelHandler(socketserver.BaseRequestHandler):
    """Forward one local TCP connection through the SSH channel."""

    def handle(self) -> None:
        server: _TunnelServer = self.server  # type: ignore[assignment]
        try:
            chan = server.ssh_transport.open_channel(
                "direct-tcpip",
                (server.remote_host, server.remote_port),
                self.request.getpeername(),
            )
        except Exception:
            return
        if chan is None:
            return
        try:
            while True:
                r, _, _ = select.select([self.request, chan], [], [], 1.0)
                if self.request in r:
                    data = self.request.recv(4096)
                    if not data:
                        break
                    chan.sendall(data)
                if chan in r:
                    data = chan.recv(4096)
                    if not data:
                        break
                    self.request.sendall(data)
        finally:
            chan.close()


class _TunnelServer(socketserver.ThreadingTCPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(
        self,
        local_address: tuple[str, int],
        handler: type[socketserver.BaseRequestHandler],
        ssh_transport: paramiko.Transport,
        remote_host: str,
        remote_port: int,
    ) -> None:
        self.ssh_transport = ssh_transport
        self.remote_host = remote_host
        self.remote_port = remote_port
        super().__init__(local_address, handler)


class _SSHTunnel:
    """Minimal SSH local-port-forward tunnel using paramiko directly.

    Exposes the same interface used by the connector:
    ``local_bind_host``, ``local_bind_port``, ``start()``, ``stop()``.
    """

    local_bind_host: str
    local_bind_port: int

    def __init__(
        self,
        tunnel_cfg: SSHTunnelConfig,
        remote_host: str,
        remote_port: int,
    ) -> None:
        ssh_password = tunnel_cfg.password.get_secret_value() if tunnel_cfg.password else None
        key_passphrase = tunnel_cfg.private_key_passphrase.get_secret_value() if tunnel_cfg.private_key_passphrase else None

        transport = paramiko.Transport((tunnel_cfg.host, tunnel_cfg.port))
        transport.start_client()

        if tunnel_cfg.private_key is not None:
            pkey = _load_ssh_private_key(tunnel_cfg.private_key.get_secret_value(), key_passphrase)
            transport.auth_publickey(tunnel_cfg.username, pkey)
        elif ssh_password is not None:
            transport.auth_password(tunnel_cfg.username, ssh_password)
        else:
            transport.close()
            raise paramiko.AuthenticationException("SSH tunnel requires either private_key or password.")

        if not transport.is_authenticated():
            transport.close()
            raise paramiko.AuthenticationException("SSH authentication failed.")

        local_port = tunnel_cfg.local_bind_port or 0
        server = _TunnelServer(("127.0.0.1", local_port), _TunnelHandler, transport, remote_host, remote_port)

        self.local_bind_host = "127.0.0.1"
        self.local_bind_port = server.server_address[1]
        self._transport = transport
        self._server = server
        self._thread = threading.Thread(target=server.serve_forever, daemon=True)

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._server.shutdown()
        self._transport.close()


# ContextVar holding the active transaction connection for the current async task.
# When set, execute/fetch methods use this connection instead of acquiring from pool,
# ensuring all operations within a transaction see uncommitted writes.
# asyncpg.Pool.acquire() yields PoolConnectionProxy, which wraps _ConnectionProxy
# and is NOT a subclass of asyncpg.Connection — use the correct type here.
_active_conn: contextvars.ContextVar[PoolConnectionProxy | None] = contextvars.ContextVar("_pg_active_conn", default=None)

# Pattern to extract rowcount from asyncpg command status strings like:
#   "INSERT 0 3", "UPDATE 5", "DELETE 2", "SELECT 10", "CREATE TABLE"
_STATUS_RE = re.compile(r"^(?:INSERT \d+ |UPDATE |DELETE |SELECT )(\d+)$")


def _parse_rowcount(status: str) -> int:
    """Extract the affected row count from an asyncpg command status string."""
    m = _STATUS_RE.match(status.strip())
    return int(m.group(1)) if m else -1


def _records_to_rows(records: list[asyncpg.Record]) -> Rows:
    return [dict(r) for r in records]


class PostgresConnector(BaseConnector):
    """Async PostgreSQL connector backed by an asyncpg connection pool.

    SQL parameter placeholders use PostgreSQL native style: ``$1``, ``$2``, etc.

    Transactions are propagated transparently via a ``contextvars.ContextVar``:
    all ``execute`` / ``fetch_*`` calls within an ``async with connector.transaction()``
    block automatically use the same connection, ensuring uncommitted writes are visible.

    Parameters
    ----------
    config: PostgresConfig instance.
    """

    def __init__(self, config: PostgresConfig) -> None:  # type: ignore[override]
        super().__init__(config)
        self._config: PostgresConfig = config
        self._pool: asyncpg.Pool | None = None
        self._tunnel: _SSHTunnel | None = None

    def _ensure_pool(self) -> asyncpg.Pool:
        if self._pool is None:
            raise ConnectionError("PostgreSQL connector is not connected. Call connect() or use it as an async context manager.")
        return self._pool

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Create the asyncpg connection pool (no-op if already connected).

        If ``ssh_tunnel`` is configured, an SSH tunnel is started first and
        asyncpg connects to its local bind address instead of the database
        host directly.
        """
        if self._pool is not None:
            return

        cfg = self._config
        ssl_ctx = cfg.ssl.to_ssl_context()

        pg_host = cfg.host
        pg_port = cfg.port

        if cfg.ssh_tunnel is not None:
            self._logger.info(
                "Starting SSH tunnel via %s:%d -> %s:%d",
                cfg.ssh_tunnel.host,
                cfg.ssh_tunnel.port,
                cfg.host,
                cfg.port,
            )
            try:
                tunnel = await asyncio.to_thread(self._start_tunnel, cfg.ssh_tunnel, cfg.host, cfg.port)
            except Exception as exc:
                raise ConnectionError(
                    f"Failed to open SSH tunnel to {cfg.ssh_tunnel.host}:{cfg.ssh_tunnel.port}",
                    original=exc,
                ) from exc
            self._tunnel = tunnel
            pg_host = tunnel.local_bind_host
            pg_port = tunnel.local_bind_port
            self._logger.info("SSH tunnel established on 127.0.0.1:%d.", pg_port)

        self._logger.info(
            "Creating PostgreSQL pool: host=%s port=%d database=%s",
            pg_host,
            pg_port,
            cfg.database,
        )
        try:
            self._pool = await asyncpg.create_pool(
                host=pg_host,
                port=pg_port,
                database=cfg.database,
                user=cfg.username,
                password=cfg.password.get_secret_value(),
                min_size=cfg.pool_min_size,
                max_size=cfg.pool_max_size,
                timeout=cfg.connect_timeout,
                ssl=ssl_ctx,
                statement_cache_size=cfg.statement_cache_size,
                max_inactive_connection_lifetime=cfg.max_inactive_connection_lifetime,
                command_timeout=cfg.command_timeout,
            )
        except (asyncpg.PostgresError, OSError) as exc:
            # Tear down the tunnel if pool creation fails
            if self._tunnel is not None:
                await asyncio.to_thread(self._tunnel.stop)
                self._tunnel = None
            raise ConnectionError(
                f"Cannot connect to PostgreSQL at {cfg.host}:{cfg.port}/{cfg.database}",
                original=exc,
            ) from exc
        self._logger.info("PostgreSQL pool created (min=%d max=%d).", cfg.pool_min_size, cfg.pool_max_size)

    @staticmethod
    def _start_tunnel(
        tunnel_cfg: SSHTunnelConfig,
        remote_host: str,
        remote_port: int,
    ) -> _SSHTunnel:
        """Start and return an SSH tunnel (blocking — run via asyncio.to_thread)."""
        tunnel = _SSHTunnel(tunnel_cfg, remote_host, remote_port)
        tunnel.start()
        return tunnel

    async def disconnect(self) -> None:
        """Close all connections in the pool and stop any active SSH tunnel."""
        if self._pool is None:
            return
        pool = self._pool
        self._pool = None
        await pool.close()
        if self._tunnel is not None:
            await asyncio.to_thread(self._tunnel.stop)
            self._tunnel = None
        self._logger.info("PostgreSQL pool closed.")

    async def test_connection(self) -> bool:
        """Verify connectivity by running ``SELECT 1``."""
        pool = self._ensure_pool()
        try:
            async with pool.acquire() as conn:
                await conn.fetchval("SELECT 1")
        except (asyncpg.PostgresError, OSError) as exc:
            raise ConnectionError(
                "PostgreSQL connection test failed.",
                original=exc,
            ) from exc
        return True

    # ------------------------------------------------------------------
    # Internal: connection acquisition (respects active transaction)
    # ------------------------------------------------------------------

    @asynccontextmanager
    async def _acquire(self) -> AsyncIterator[PoolConnectionProxy]:
        """Yield the active transaction connection or acquire one from the pool."""
        tx_conn = _active_conn.get()
        if tx_conn is not None:
            yield tx_conn
        else:
            pool = self._ensure_pool()
            async with pool.acquire() as conn:
                yield conn

    # ------------------------------------------------------------------
    # Query execution
    # ------------------------------------------------------------------

    async def execute(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> QueryResult:
        """Execute a non-SELECT SQL statement."""
        self._logger.debug("execute: %s | params=%s", query[:200], params)
        args = list(params) if params else []
        async with self._acquire() as conn:
            try:
                status: str = await conn.execute(query, *args)
                return QueryResult(rowcount=_parse_rowcount(status))
            except asyncpg.PostgresError as exc:
                raise QueryError(
                    f"PostgreSQL query failed: {query[:80]}",
                    original=exc,
                ) from exc

    async def fetch_one(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Row | None:
        """Execute a SELECT and return the first row as a dict, or None."""
        self._logger.debug("fetch_one: %s | params=%s", query[:200], params)
        args = list(params) if params else []
        async with self._acquire() as conn:
            try:
                record: asyncpg.Record | None = await conn.fetchrow(query, *args)
                return dict(record) if record is not None else None
            except asyncpg.PostgresError as exc:
                raise QueryError(
                    f"PostgreSQL query failed: {query[:80]}",
                    original=exc,
                ) from exc

    async def fetch_all(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Rows:
        """Execute a SELECT and return all rows as a list of dicts."""
        self._logger.debug("fetch_all: %s | params=%s", query[:200], params)
        args = list(params) if params else []
        async with self._acquire() as conn:
            try:
                records: list[asyncpg.Record] = await conn.fetch(query, *args)
                return _records_to_rows(records)
            except asyncpg.PostgresError as exc:
                raise QueryError(
                    f"PostgreSQL query failed: {query[:80]}",
                    original=exc,
                ) from exc

    async def execute_many(
        self,
        query: str,
        params_seq: list[tuple[Any, ...]] | list[list[Any]],
    ) -> QueryResult:
        """Execute a parameterised statement in bulk using asyncpg executemany."""
        self._logger.debug("execute_many: %s | %d param sets", query[:200], len(params_seq))
        # asyncpg executemany expects list of tuples/lists
        args_list = [list(p) for p in params_seq]
        async with self._acquire() as conn:
            try:
                await conn.executemany(query, args_list)
                # asyncpg executemany does not return a status string; report -1
                return QueryResult(rowcount=-1)
            except asyncpg.PostgresError as exc:
                raise QueryError(
                    f"PostgreSQL execute_many failed: {query[:80]}",
                    original=exc,
                ) from exc

    # ------------------------------------------------------------------
    # Transactions
    # ------------------------------------------------------------------

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[None]:
        """Async context manager wrapping work in a PostgreSQL transaction.

        Acquires a dedicated connection from the pool and sets it as the active
        connection for the current async task via ``_active_conn``. All
        ``execute`` / ``fetch_*`` calls within the block transparently use this
        connection, ensuring uncommitted writes are visible.

        Commits on success, rolls back and raises ``TransactionError`` on failure.
        """
        pool = self._ensure_pool()
        async with pool.acquire() as conn, conn.transaction():
            token = _active_conn.set(conn)
            self._logger.debug("PostgreSQL transaction begun.")
            try:
                yield
                self._logger.debug("PostgreSQL transaction committed.")
            except Exception as exc:
                self._logger.debug("PostgreSQL transaction rolled back.")
                raise TransactionError(
                    "PostgreSQL transaction rolled back due to an error.",
                    original=exc,
                ) from exc
            finally:
                _active_conn.reset(token)
