"""PostgreSQL connector — async-native via asyncpg with connection pooling."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
import contextvars
import logging
import re
from typing import TYPE_CHECKING, Any

import asyncpg

from ignite_data_connectors.base import BaseConnector
from ignite_data_connectors.exceptions import (
    ConnectionError,
    QueryError,
    TransactionError,
)
from ignite_data_connectors.types import QueryResult, Row, Rows

if TYPE_CHECKING:
    from asyncpg.pool import PoolConnectionProxy

    from ignite_data_connectors.types import PostgresConfig

logger = logging.getLogger(__name__)

# ContextVar holding the active transaction connection for the current async task.
# When set, execute/fetch methods use this connection instead of acquiring from pool,
# ensuring all operations within a transaction see uncommitted writes.
# asyncpg.Pool.acquire() yields PoolConnectionProxy, which wraps _ConnectionProxy
# and is NOT a subclass of asyncpg.Connection — use the correct type here.
_active_conn: contextvars.ContextVar[PoolConnectionProxy | None] = contextvars.ContextVar("_pg_active_conn", default=None)

# Pattern to extract rowcount from asyncpg command status strings like:
#   "INSERT 0 3", "UPDATE 5", "DELETE 2", "SELECT 10", "CREATE TABLE"
_STATUS_RE = re.compile(r"^(?:INSERT \d+ |UPDATE |DELETE |SELECT )(\d+)$")


def _parse_rowcount(status: str) -> int:
    """Extract the affected row count from an asyncpg command status string."""
    m = _STATUS_RE.match(status.strip())
    return int(m.group(1)) if m else -1


def _records_to_rows(records: list[asyncpg.Record]) -> Rows:
    return [dict(r) for r in records]


class PostgresConnector(BaseConnector):
    """Async PostgreSQL connector backed by an asyncpg connection pool.

    SQL parameter placeholders use PostgreSQL native style: ``$1``, ``$2``, etc.

    Transactions are propagated transparently via a ``contextvars.ContextVar``:
    all ``execute`` / ``fetch_*`` calls within an ``async with connector.transaction()``
    block automatically use the same connection, ensuring uncommitted writes are visible.

    Parameters
    ----------
    config: PostgresConfig instance.
    """

    def __init__(self, config: PostgresConfig) -> None:  # type: ignore[override]
        super().__init__(config)
        self._config: PostgresConfig = config
        self._pool: asyncpg.Pool | None = None

    def _ensure_pool(self) -> asyncpg.Pool:
        if self._pool is None:
            raise ConnectionError("PostgreSQL connector is not connected. Call connect() or use it as an async context manager.")
        return self._pool

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Create the asyncpg connection pool (no-op if already connected)."""
        if self._pool is not None:
            return

        cfg = self._config
        ssl_ctx = cfg.ssl.to_ssl_context()

        self._logger.info(
            "Creating PostgreSQL pool: host=%s port=%d database=%s",
            cfg.host,
            cfg.port,
            cfg.database,
        )
        try:
            self._pool = await asyncpg.create_pool(
                host=cfg.host,
                port=cfg.port,
                database=cfg.database,
                user=cfg.username,
                password=cfg.password.get_secret_value(),
                min_size=cfg.pool_min_size,
                max_size=cfg.pool_max_size,
                timeout=cfg.connect_timeout,
                ssl=ssl_ctx,
                statement_cache_size=cfg.statement_cache_size,
                max_inactive_connection_lifetime=cfg.max_inactive_connection_lifetime,
                command_timeout=cfg.command_timeout,
            )
        except (asyncpg.PostgresError, OSError) as exc:
            raise ConnectionError(
                f"Cannot connect to PostgreSQL at {cfg.host}:{cfg.port}/{cfg.database}",
                original=exc,
            ) from exc
        self._logger.info("PostgreSQL pool created (min=%d max=%d).", cfg.pool_min_size, cfg.pool_max_size)

    async def disconnect(self) -> None:
        """Close all connections in the pool."""
        if self._pool is None:
            return
        pool = self._pool
        self._pool = None
        await pool.close()
        self._logger.info("PostgreSQL pool closed.")

    async def test_connection(self) -> bool:
        """Verify connectivity by running ``SELECT 1``."""
        pool = self._ensure_pool()
        try:
            async with pool.acquire() as conn:
                await conn.fetchval("SELECT 1")
        except (asyncpg.PostgresError, OSError) as exc:
            raise ConnectionError(
                "PostgreSQL connection test failed.",
                original=exc,
            ) from exc
        return True

    # ------------------------------------------------------------------
    # Internal: connection acquisition (respects active transaction)
    # ------------------------------------------------------------------

    @asynccontextmanager
    async def _acquire(self) -> AsyncIterator[PoolConnectionProxy]:
        """Yield the active transaction connection or acquire one from the pool."""
        tx_conn = _active_conn.get()
        if tx_conn is not None:
            yield tx_conn
        else:
            pool = self._ensure_pool()
            async with pool.acquire() as conn:
                yield conn

    # ------------------------------------------------------------------
    # Query execution
    # ------------------------------------------------------------------

    async def execute(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> QueryResult:
        """Execute a non-SELECT SQL statement."""
        self._logger.debug("execute: %s | params=%s", query[:200], params)
        args = list(params) if params else []
        async with self._acquire() as conn:
            try:
                status: str = await conn.execute(query, *args)
                return QueryResult(rowcount=_parse_rowcount(status))
            except asyncpg.PostgresError as exc:
                raise QueryError(
                    f"PostgreSQL query failed: {query[:80]}",
                    original=exc,
                ) from exc

    async def fetch_one(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Row | None:
        """Execute a SELECT and return the first row as a dict, or None."""
        self._logger.debug("fetch_one: %s | params=%s", query[:200], params)
        args = list(params) if params else []
        async with self._acquire() as conn:
            try:
                record: asyncpg.Record | None = await conn.fetchrow(query, *args)
                return dict(record) if record is not None else None
            except asyncpg.PostgresError as exc:
                raise QueryError(
                    f"PostgreSQL query failed: {query[:80]}",
                    original=exc,
                ) from exc

    async def fetch_all(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Rows:
        """Execute a SELECT and return all rows as a list of dicts."""
        self._logger.debug("fetch_all: %s | params=%s", query[:200], params)
        args = list(params) if params else []
        async with self._acquire() as conn:
            try:
                records: list[asyncpg.Record] = await conn.fetch(query, *args)
                return _records_to_rows(records)
            except asyncpg.PostgresError as exc:
                raise QueryError(
                    f"PostgreSQL query failed: {query[:80]}",
                    original=exc,
                ) from exc

    async def execute_many(
        self,
        query: str,
        params_seq: list[tuple[Any, ...]] | list[list[Any]],
    ) -> QueryResult:
        """Execute a parameterised statement in bulk using asyncpg executemany."""
        self._logger.debug("execute_many: %s | %d param sets", query[:200], len(params_seq))
        # asyncpg executemany expects list of tuples/lists
        args_list = [list(p) for p in params_seq]
        async with self._acquire() as conn:
            try:
                await conn.executemany(query, args_list)
                # asyncpg executemany does not return a status string; report -1
                return QueryResult(rowcount=-1)
            except asyncpg.PostgresError as exc:
                raise QueryError(
                    f"PostgreSQL execute_many failed: {query[:80]}",
                    original=exc,
                ) from exc

    # ------------------------------------------------------------------
    # Transactions
    # ------------------------------------------------------------------

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[None]:
        """Async context manager wrapping work in a PostgreSQL transaction.

        Acquires a dedicated connection from the pool and sets it as the active
        connection for the current async task via ``_active_conn``. All
        ``execute`` / ``fetch_*`` calls within the block transparently use this
        connection, ensuring uncommitted writes are visible.

        Commits on success, rolls back and raises ``TransactionError`` on failure.
        """
        pool = self._ensure_pool()
        async with pool.acquire() as conn, conn.transaction():
            token = _active_conn.set(conn)
            self._logger.debug("PostgreSQL transaction begun.")
            try:
                yield
                self._logger.debug("PostgreSQL transaction committed.")
            except Exception as exc:
                self._logger.debug("PostgreSQL transaction rolled back.")
                raise TransactionError(
                    "PostgreSQL transaction rolled back due to an error.",
                    original=exc,
                ) from exc
            finally:
                _active_conn.reset(token)
