"""DuckDB connector — synchronous DuckDB wrapped with asyncio.to_thread."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
import contextvars
import logging
from typing import TYPE_CHECKING, Any

import duckdb

from ignite_data_connectors.base import BaseConnector
from ignite_data_connectors.exceptions import (
    ConnectionError,
    QueryError,
    TransactionError,
)
from ignite_data_connectors.types import QueryResult, Row, Rows

if TYPE_CHECKING:
    from ignite_data_connectors.types import DuckDBConfig

logger = logging.getLogger(__name__)

# DuckDB parameter placeholder style is positional list: [val1, val2, ...]
# SQL uses ? for parameters but DuckDB also accepts $1/$2 syntax.
# We normalise to list for all internal calls.

# ContextVar to track whether the current async task is inside a DuckDB transaction.
# When True, query methods use self._conn directly (not conn.cursor()) so that
# the in-progress transaction is visible to all statements in the block.
# The asyncio.to_thread() propagates ContextVar values to worker threads automatically.
_in_transaction: contextvars.ContextVar[bool] = contextvars.ContextVar("_duckdb_in_transaction", default=False)


def _params_to_list(
    params: tuple[Any, ...] | list[Any] | None,
) -> list[Any]:
    if params is None:
        return []
    return list(params)


class DuckDBConnector(BaseConnector):
    """Async-compatible DuckDB connector.

    DuckDB operates in-process using a single connection. All synchronous
    DuckDB calls are dispatched to a thread pool via ``asyncio.to_thread``.
    A lock serialises write operations to prevent concurrent transaction
    interleaving.

    Each call creates a new cursor via ``conn.cursor()``, which is safe for
    concurrent reads from multiple coroutines. Write operations (including
    transactions) hold ``self._write_lock`` to guarantee isolation.

    Parameters
    ----------
    config: DuckDBConfig instance with database path and optional settings.
    """

    def __init__(self, config: DuckDBConfig) -> None:  # type: ignore[override]
        super().__init__(config)
        self._config: DuckDBConfig = config
        self._conn: duckdb.DuckDBPyConnection | None = None
        self._write_lock = asyncio.Lock()

    def _ensure_connected(self) -> duckdb.DuckDBPyConnection:
        if self._conn is None:
            raise ConnectionError("DuckDB connector is not connected. Call connect() or use it as an async context manager.")
        return self._conn

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Open the DuckDB connection (no-op if already connected)."""
        if self._conn is not None:
            return

        cfg = self._config

        def _open() -> duckdb.DuckDBPyConnection:
            return duckdb.connect(
                database=cfg.database,
                read_only=cfg.read_only,
                config=cfg.config if cfg.config else {},
            )

        self._logger.info(
            "Connecting to DuckDB database: %s (read_only=%s)",
            cfg.database,
            cfg.read_only,
        )
        try:
            self._conn = await asyncio.wait_for(
                asyncio.to_thread(_open),
                timeout=self._config.connect_timeout,
            )
        except duckdb.Error as exc:
            raise ConnectionError(
                f"Cannot open DuckDB database: {cfg.database}",
                original=exc,
            ) from exc
        self._logger.info("DuckDB connection established.")

    async def disconnect(self) -> None:
        """Close the DuckDB connection."""
        if self._conn is None:
            return
        conn = self._conn
        self._conn = None

        def _close() -> None:
            conn.close()

        await asyncio.to_thread(_close)
        self._logger.info("DuckDB connection closed.")

    async def test_connection(self) -> bool:
        """Verify the connection by executing ``SELECT 1``."""
        conn = self._ensure_connected()

        def _ping() -> None:
            conn.execute("SELECT 1")

        try:
            await asyncio.to_thread(_ping)
        except duckdb.Error as exc:
            raise ConnectionError(
                "DuckDB connection test failed.",
                original=exc,
            ) from exc
        return True

    # ------------------------------------------------------------------
    # Query execution
    # ------------------------------------------------------------------

    def _cursor(self, conn: duckdb.DuckDBPyConnection) -> duckdb.DuckDBPyConnection:
        """Return the correct cursor for the current context.

        Inside a transaction the main connection is used directly so that all
        statements participate in the same transaction.  Outside a transaction
        a fresh ``conn.cursor()`` is used, which is safe for concurrent reads
        from multiple coroutines dispatched to the thread pool.
        """
        return conn if _in_transaction.get() else conn.cursor()

    async def execute(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> QueryResult:
        """Execute a non-SELECT SQL statement."""
        conn = self._ensure_connected()
        p = _params_to_list(params)
        self._logger.debug("execute: %s | params=%s", query[:200], p)

        def _run() -> QueryResult:
            cur = self._cursor(conn)
            cur.execute(query, p)
            # DuckDB rowcount is -1 for DDL, otherwise reflects affected rows.
            return QueryResult(rowcount=cur.rowcount if cur.rowcount is not None else -1)

        try:
            return await asyncio.to_thread(_run)
        except duckdb.Error as exc:
            raise QueryError(
                f"DuckDB query failed: {query[:80]}",
                original=exc,
            ) from exc

    async def fetch_one(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Row | None:
        """Execute a SELECT and return the first row as a dict, or None."""
        conn = self._ensure_connected()
        p = _params_to_list(params)
        self._logger.debug("fetch_one: %s | params=%s", query[:200], p)

        def _run() -> Row | None:
            cur = self._cursor(conn)
            cur.execute(query, p)
            row = cur.fetchone()
            if row is None:
                return None
            cols = [desc[0] for desc in cur.description]
            return dict(zip(cols, row))

        try:
            return await asyncio.to_thread(_run)
        except duckdb.Error as exc:
            raise QueryError(
                f"DuckDB query failed: {query[:80]}",
                original=exc,
            ) from exc

    async def fetch_all(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Rows:
        """Execute a SELECT and return all rows as a list of dicts."""
        conn = self._ensure_connected()
        p = _params_to_list(params)
        self._logger.debug("fetch_all: %s | params=%s", query[:200], p)

        def _run() -> Rows:
            cur = self._cursor(conn)
            cur.execute(query, p)
            rows = cur.fetchall()
            cols = [desc[0] for desc in cur.description]
            return [dict(zip(cols, row)) for row in rows]

        try:
            return await asyncio.to_thread(_run)
        except duckdb.Error as exc:
            raise QueryError(
                f"DuckDB query failed: {query[:80]}",
                original=exc,
            ) from exc

    async def execute_many(
        self,
        query: str,
        params_seq: list[tuple[Any, ...]] | list[list[Any]],
    ) -> QueryResult:
        """Execute a parameterised statement repeatedly in bulk.

        Returns immediately with ``rowcount=-1`` when ``params_seq`` is empty,
        as DuckDB rejects an empty parameter list for executemany.
        """
        conn = self._ensure_connected()
        if not params_seq:
            return QueryResult(rowcount=-1)
        params_list = [list(p) for p in params_seq]
        self._logger.debug("execute_many: %s | %d param sets", query[:200], len(params_list))

        def _run() -> QueryResult:
            cur = self._cursor(conn)
            cur.executemany(query, params_list)
            rowcount = cur.rowcount if cur.rowcount is not None else -1
            return QueryResult(rowcount=rowcount)

        try:
            return await asyncio.to_thread(_run)
        except duckdb.Error as exc:
            raise QueryError(
                f"DuckDB execute_many failed: {query[:80]}",
                original=exc,
            ) from exc

    # ------------------------------------------------------------------
    # Transactions
    # ------------------------------------------------------------------

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[None]:
        """Async context manager wrapping work in a DuckDB transaction.

        Acquires the write lock for the duration to prevent interleaving.
        Commits on success, rolls back and raises ``TransactionError`` on failure.
        """
        conn = self._ensure_connected()

        async with self._write_lock:

            def _begin() -> None:
                conn.execute("BEGIN TRANSACTION")

            await asyncio.to_thread(_begin)
            self._logger.debug("DuckDB transaction begun.")
            # Signal to execute/fetch methods to use self._conn directly so that
            # they participate in this transaction (not a separate cursor).
            token = _in_transaction.set(True)
            try:
                yield
                await asyncio.to_thread(conn.execute, "COMMIT")
                self._logger.debug("DuckDB transaction committed.")
            except Exception as exc:
                try:
                    await asyncio.to_thread(conn.execute, "ROLLBACK")
                    self._logger.debug("DuckDB transaction rolled back.")
                except duckdb.Error:
                    pass  # Best-effort rollback; original exception takes priority
                raise TransactionError(
                    "DuckDB transaction rolled back due to an error.",
                    original=exc,
                ) from exc
            finally:
                _in_transaction.reset(token)
