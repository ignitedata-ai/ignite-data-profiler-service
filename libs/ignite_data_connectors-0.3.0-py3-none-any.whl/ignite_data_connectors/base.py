"""Abstract base class for all database connectors."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
import logging
from typing import TYPE_CHECKING, Any

from ignite_data_connectors.types import QueryResult, Row, Rows

if TYPE_CHECKING:
    from ignite_data_connectors.types import ConnectorConfig

logger = logging.getLogger(__name__)


class BaseConnector(ABC):
    """Abstract async database connector.

    All concrete implementations must provide every abstract method.
    The async context manager protocol (``__aenter__`` / ``__aexit__``)
    is implemented here and delegates to ``connect`` and ``disconnect``.

    Usage
    -----
    Preferred — async context manager (handles connect/disconnect automatically)::

        async with create_connector(config) as conn:
            rows = await conn.fetch_all("SELECT * FROM users")

    Manual lifecycle management::

        conn = create_connector(config)
        await conn.connect()
        try:
            rows = await conn.fetch_all("SELECT * FROM users")
        finally:
            await conn.disconnect()
    """

    def __init__(self, config: ConnectorConfig) -> None:
        self._config = config
        self._logger = logging.getLogger(f"ignite_data_connectors.{type(self).__name__.lower()}")

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    @abstractmethod
    async def connect(self) -> None:
        """Open the connection or create the connection pool.

        Idempotent: calling connect on an already-connected instance is a no-op.
        """

    @abstractmethod
    async def disconnect(self) -> None:
        """Close the connection or pool, releasing all resources.

        Safe to call even if connect() was never called.
        """

    @abstractmethod
    async def test_connection(self) -> bool:
        """Verify connectivity by running a trivial query.

        Returns:
        -------
        True on success.

        Raises:
        ------
        ConnectionError
            If the connection cannot be established or the ping query fails.
        """

    # ------------------------------------------------------------------
    # Query execution
    # ------------------------------------------------------------------

    @abstractmethod
    async def execute(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> QueryResult:
        """Execute a non-SELECT statement (INSERT / UPDATE / DELETE / DDL).

        Parameters
        ----------
        query:
            SQL string with driver-native placeholders:
            ``$1, $2`` for PostgreSQL, ``%s`` for MySQL, ``?`` for DuckDB.
        params:
            Positional bind parameters as a tuple or list.

        Returns:
        -------
        QueryResult
            Contains ``rowcount`` (number of affected rows, -1 for DDL)
            and ``last_id`` (last inserted auto-increment ID, if applicable).

        Raises:
        ------
        QueryError
            If the SQL statement fails.
        ConnectionError
            If there is no active connection.
        """

    @abstractmethod
    async def fetch_one(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Row | None:
        """Execute a SELECT and return the first row as a dict, or None.

        Parameters
        ----------
        query:  SQL SELECT statement with driver-native placeholders.
        params: Positional bind parameters.

        Returns:
        -------
        A ``dict[str, Any]`` mapping column names to values, or ``None`` if
        the query returned no rows.

        Raises:
        ------
        QueryError
            If the SQL statement fails.
        """

    @abstractmethod
    async def fetch_all(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | None = None,
    ) -> Rows:
        """Execute a SELECT and return all rows as a list of dicts.

        Parameters
        ----------
        query:  SQL SELECT statement with driver-native placeholders.
        params: Positional bind parameters.

        Returns:
        -------
        A ``list[dict[str, Any]]``. Empty list if no rows match.

        Raises:
        ------
        QueryError
            If the SQL statement fails.
        """

    @abstractmethod
    async def execute_many(
        self,
        query: str,
        params_seq: list[tuple[Any, ...]] | list[list[Any]],
    ) -> QueryResult:
        """Execute a parameterised statement repeatedly over a sequence of params.

        Implementations use the driver's native bulk-insert optimisation where
        available (e.g. asyncpg ``executemany``, aiomysql ``executemany``).

        Parameters
        ----------
        query:      SQL statement with driver-native placeholders.
        params_seq: A list of parameter tuples/lists, one per execution.

        Returns:
        -------
        QueryResult
            ``rowcount`` is the total number of affected rows when deterministic,
            else -1.

        Raises:
        ------
        QueryError
            If any execution in the batch fails.
        """

    # ------------------------------------------------------------------
    # Transactions
    # ------------------------------------------------------------------

    @abstractmethod
    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[None]:
        """Async context manager that wraps work in a database transaction.

        On normal exit the transaction is committed. On any exception the
        transaction is rolled back and a ``TransactionError`` is raised.

        Usage
        -----
        ::

            async with connector.transaction():
                await connector.execute("INSERT INTO ...")
                await connector.execute("UPDATE ...")

        Raises:
        ------
        TransactionError
            If begin, commit, or rollback fails, or if the block raises.
        """
        # Abstract generators must yield to satisfy the asynccontextmanager protocol.
        # Concrete subclasses override this body entirely.
        yield  # type: ignore[misc]

    # ------------------------------------------------------------------
    # Async context manager
    # ------------------------------------------------------------------

    async def __aenter__(self) -> BaseConnector:
        await self.connect()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        await self.disconnect()
